IDE :protect nay duoc viet tren dev C phien ban 5.11
cac tinh nang nang cao da cai dat:  chuc nang them tai khoan , neu da co tk roi khong cho them, dam bao tk la duy nhat
                                    Chuc nang x�a t�i khoan: Neu kh�ng t�m thay t�i khoan th� hien ra th�ng b�o kh�ng t�m thay, v� khi d� moi thuc hien x�a t�i khoan trong tep nhi ph�n
                                    Chuc nang hien thi danh s�ch t�i khoan: Du lieu xuat ra can chinh cho dep
                                    Kiem tra du lieu dau v�o khi nguoi d�ng nhap kh�ng d�ng (v� du so t�i khoan l� so nhap l� kieu chuoi, so tien nhung lai nhap l� k� tu�)