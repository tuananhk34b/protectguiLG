#include <iostream>
#include "account.h"
#include <vector>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void CreateAccount(vector<Account> &dstk);
void SearchAndPrintAccount(vector<Account> dstk,int sotaikhoan);
void SearchAndModifyAccount(vector<Account> &dstk,int sotaikhoan);
void DeleteAccount(vector<Account> &dstk,int k);
void PrintAllAccountInFormat(vector<Account> dstk);
void DepositOrWithdraw(vector<Account> &dstk,int chon,int sotaikhoan);

void LuuFile(Account tk) {
	ofstream outfile("Account.dat", ios::binary|ios::app);
	outfile.write((char*)&tk, sizeof(tk));
	outfile.close();
}

void LuuFileMoi(vector<Account> dstk) {
   ofstream outfile("Account.dat", ios::binary);
   for(int i = 0;i < dstk.size();i++)
   {
   	    outfile.write((char*)&dstk[i], sizeof(dstk[i]));
   }
   outfile.close();
}

void DocFile(vector<Account> &dstk,int &k) {
  ifstream infile("Account.dat", ios::binary|ios::app); 
  if (!infile.is_open()){
  	 cout<<"khong the mo duoc file,hay nhan phim enter de quay lai menu chinh";
  }
  else{
  	  k = 1;
  	  while(!infile.eof()){
  	  	    Account tk;
            infile.read((char*)&tk, sizeof(tk));
            if(infile.eof()){
            	break;
		    }
		    dstk.push_back(tk);
	  }
  }
  infile.close();
}

void TimKiem(vector<Account> dstk,int so_tai_khoan,int &k)
{   
	for(int i = 0; i < dstk.size() ;i++)
	{
		 if (dstk[i].LaySoTaiKhoan()==so_tai_khoan){
		 	 dstk[i].Xuat();
			 k = 1;	
		 }
	}
}

void TimXoa(vector<Account> dstk,int so_tai_khoan,int &k,int &t)
{
	for(int i = 0; i < dstk.size() ;i++)
	{
		 if (dstk[i].LaySoTaiKhoan() == so_tai_khoan){
			 t = i;
			 k = 1;	
		 }
	}
}

int main(int argc, char** argv) {
	int chon; // Nhap tu ban phim
	vector<Account> dstk;
	do
	{
		system("cls");
		cout << "\n\n\n\tMenu";
		cout << "\n\n\t1. Tao tai khoan";
		cout << "\n\n\t2. Nop tien";
		cout << "\n\n\t3. Rut tien";
		cout << "\n\n\t4. Tra cuu tai khoan";
		cout << "\n\n\t5. Danh sach tai khoan";
		cout << "\n\n\t6. Xoa tai khoan";
		cout << "\n\n\t7. Sua tai khoan";
		cout << "\n\n\t8. Thoat";
		cout << "\n\n\tChon menu (so tu 1 den 8) ";
		cin >> chon;
		system("cls");
		switch (chon)
		{
			case 1:
				{ 
				    CreateAccount(dstk);
				}
				break;
			case 2:
				{   
				    vector<Account> dstkdl;
				    int k = 0;
				    DocFile(dstkdl,k);
				    if(k == 1){
				     	cout << "\n\n\tChon so tai khoan: ";
				     	int so_tai_khoan;
				     	cin>>so_tai_khoan;
				     	int k1 = 0;
				     	TimKiem(dstkdl,so_tai_khoan,k1);
				     	if (k1 == 0){
				     	   cout<<"\nkhong tim thay tai khoan"; 
						}
						else{
							DepositOrWithdraw(dstkdl,chon,so_tai_khoan);
							LuuFileMoi(dstkdl);
						}
					}	 
				}
				break;
			case 3:
				 {   
				    vector<Account> dstkdl;
				    int k = 0;
				    DocFile(dstkdl,k);
				    if(k == 1){
				     	cout << "\n\n\tChon so tai khoan: ";
				     	int so_tai_khoan;
				     	cin>>so_tai_khoan;
				     	int k1 = 0;
				     	TimKiem(dstkdl,so_tai_khoan,k1);
				     	if (k1 == 0){
				     	   cout<<"\nkhong tim thay tai khoan"; 
						}
						else{
							DepositOrWithdraw(dstkdl,chon,so_tai_khoan);
							LuuFileMoi(dstkdl);
						}
					}	 
				}	 
				break;
			case 4:
			     {
			     	vector<Account> dstkdl;
				    int k = 0;
					DocFile(dstkdl,k);
					if(k == 1){
					cout << "\n\n\tNhap so tai khoan: ";
					int so_tai_khoan;
					cin>>so_tai_khoan;
					SearchAndPrintAccount(dstkdl,so_tai_khoan);
				    }
				 }
				break;
			case 5:
				{
					vector<Account> dstkdl;
					int k = 0;
					DocFile(dstkdl,k);
					if(k == 1){
					   	PrintAllAccountInFormat(dstkdl);
					}
				}		 
				break;
			case 6:
				{
					vector<Account> dstkdl;
					int k = 0;
					DocFile(dstkdl,k);
					if(k == 1){
					cout << "\n\n\tNhap so tai khoan: ";
					int so_tai_khoan;
					cin>>so_tai_khoan;
					int t = -1;
					int k1 = 0;
					TimXoa(dstkdl,so_tai_khoan,k1,t);
					if (k1 == 0){
					    cout<<"\nkhong tim thay tai khoan"; 
					}
					else{
						DeleteAccount(dstkdl,t);
						LuuFileMoi(dstkdl);
						cout<<"\n\n\t tai khoan da xoa thanh cong ";
					}
				    }
				}
				break;
			case 7:
			    {   
				    vector<Account> dstkdl;
				    int k = 0;
				    DocFile(dstkdl,k);
				    if(k == 1){
				     	cout << "\n\n\tChon so tai khoan: ";
				     	int so_tai_khoan;
				     	cin>>so_tai_khoan;
				     	int k1 = 0;
				     	TimKiem(dstkdl,so_tai_khoan,k1);
				     	if (k1 == 0){
				     	   cout<<"\nkhong tim thay tai khoan"; 
						}
						else{
							SearchAndModifyAccount(dstkdl,so_tai_khoan);
							LuuFileMoi(dstkdl);
							cout<<"\n\n\ttai khoan da sua thanh cong";
						}
					}	 
				}	 
				 
				break;
			case 8:
				 cout<<"\n\n\tcam on ban da su dung dich vu, hen gap lai :";
				break;
		}
		cin.ignore();
		cin.get();
	} while (chon != 8);
	return 0;
}

void CreateAccount(vector<Account> &dstk)
{
	Account A;
	A.NhapTaiKhoan();
	int k = 0;
	//thuc hien chuc nang nang cao cua de bai ,nau da co tai khoan roi , ko cho them;
	TimKiem(dstk,A.LaySoTaiKhoan(),k);
	if(k == 0){
	   dstk.push_back(A);
	   LuuFile(A);
	}
	else{
		cout<<"\ntai khoan nay da ton tai;\n";
	}	
}

void DepositOrWithdraw(vector<Account> &dstk,int chon,int so_tai_khoan)
{
	if(chon == 2){
		cout<<"\n\n\tnop tien\n\n";
		cout<<"nhap so tien nop: ";
		int nop;
		cin>>nop;
		//thuc hien yeu cau nang cao, kiem tra ky tu nhap vao co phai so?
		while(cin.fail()){
	    	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"khong phai so,nhap lai: ";
		   	cin>>nop;
	    }
		for(int i = 0;i < dstk.size();i++)
		{   
			if(dstk[i].LaySoTaiKhoan() == so_tai_khoan){
			   dstk[i].SetSoDu(nop+dstk[i].LaySoDu());			
			}
		}
		cout<<"\n\n\t\tgiao dich thuc hien thanh cong";	
	}
	else if(chon == 3){
		cout<<"\n\n\t rut tien\n\n";
		cout<<"nhap so tien rut: ";
		int rut;
		cin>>rut;
		//thuc hien yeu cau nang cao, kiem tra ky tu nhap vao co phai so?
		while(cin.fail()){
	    	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"khong phai so,nhap lai: ";
		   	cin>>rut;
	    }
		for(int i = 0;i < dstk.size();i++)
		{
			if(dstk[i].LaySoTaiKhoan() == so_tai_khoan){
				if(rut > dstk[i].LaySoDu()){
					cout<<"\ntai khoan cua ban khong du de rut so tien nay";
				}
				else{
					dstk[i].SetSoDu(dstk[i].LaySoDu() - rut);
					cout<<"\n\n\t\tgiao dich thuc hien thanh cong";	
				}	
			}	
		}
	}
}

void SearchAndPrintAccount(vector<Account> dstk,int so_tai_khoan)
{
	int k = 0;
	cout<<"\n\n ket qua tim kiem:\n\n";
	TimKiem(dstk,so_tai_khoan,k);
	if(k == 0){
	   cout<<"\nkhong tim thay tai khoan";
	}	 
}

void PrintAllAccountInFormat(vector<Account> dstk)
{
	cout << "\n\n\t\tDanh sach tai khoan:\n\n";
	cout << "========================================================\n";
	cout << "So TK          Chu TK              Loai     So du\n";
	cout << "========================================================\n";
	for(int i = 0;i < dstk.size();i++)
	{
		dstk[i].XuatTaiKhoan();
	}
}

void DeleteAccount(vector<Account> &dstk,int k)
{
	dstk.erase(dstk.begin() + k);
}

void SearchAndModifyAccount(vector<Account> &dstk,int so_tai_khoan)
{
	cout<<"\n\n\nnhap thong tin de thay doi:\n";
	char ten[50];
	char kieu[1];
	int sodu;
	cin.ignore();
	cout<<"ten chu tai khoan: ";
    gets(ten);
	cout<<"loai tai khoan: ";
	gets(kieu);
	cout<<"so du: ";
	cin>>sodu;
	for(int i =  0;i < dstk.size();i++)
	{
		if (dstk[i].LaySoTaiKhoan() == so_tai_khoan){
			dstk[i].SetTen(ten);
			dstk[i].SetKieu(kieu);
			dstk[i].SetSoDu(sodu);
		}
	}
}
