 #include <iostream>
#include <string.h>
#include <iomanip>
#include <fstream>
using namespace std;
class Account
{
protected:
	int so_tai_khoan; // So tai khoan
	char ten[50]; // Ho ten chu tai khoan
	int so_du; // So du tai khoan
	char kieu[1]; // Kieu tai khoan. N: binh thuong. V: tai khoan Vip
public:
	 void NhapTaiKhoan()
	 {
	 	cout<<"\nnhap so tai khoan: ";
	 	cin>>so_tai_khoan;
	 	//thuc hien yeu cau nang cao, kiem tra ky tu nhap vao co phai so?
	 	while(cin.fail()){
	    	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"khong phai so,nhap lai: ";
		   	cin>>so_tai_khoan;
	    }
	 	cin.ignore();
	 	cout<<"\nnhap ten chu tai khoan: ";
	    gets(ten);
	 	cout<<"\nnhap loai tai khoan: ";
	 	gets(kieu);
	 	cout<<"\nnhap so du ban dau: ";
	 	cin>>so_du;
	 	//thuc hien yeu cau nang cao, kiem tra ky tu nhap vao co phai so?
	 	while(cin.fail()){
	    	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"khong phai so,nhap lai: ";
		   	cin>>so_du;
	    }
	 }
	 
	 void XuatTaiKhoan()
	 {
	 	cout<<setw(15)<<left<<so_tai_khoan<<setw(20)<<left<<ten<<setw(9)<<left<<kieu;
		cout<<setw(24)<<left<<so_du<<endl;
	 }
	 
	 void Xuat()
	 {
	 	cout<<"\n\nso tai khoan: "<<so_tai_khoan;
	 	cout<<"\nten chu tai khoan: "<<ten;
	 	cout<<"\nloai tai khoan: "<<kieu;
	 	cout<<"\nso du: "<<so_du;
	 }
	 
	 int LaySoTaiKhoan()
	 {
	 	return so_tai_khoan;
	 }
	 
	 int LaySoDu()
	 {
	 	return so_du;
	 }
	 
	 void SetSoDu(int n)
	 {
	 	so_du = n;
	 }
	 
	 void SetTen(char ten1[50])
	 {
	 	strcpy(ten,ten1);
	 }
	 
	 void SetKieu(char kieu1[1])
	 {
	 	strcpy(kieu,kieu1);
	 }
};
