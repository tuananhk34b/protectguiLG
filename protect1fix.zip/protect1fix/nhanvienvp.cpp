#include "nhanvienvp.h"
int NhanVienVanPhong ::LayLoai()
{
	return loai;
}

string  NhanVienVanPhong::LayNgaySinh()
{
	return ngay_sinh;
}

string NhanVienVanPhong ::LayTen()
{
	return ten;
}

void  NhanVienVanPhong::Nhap()
{
	NhanVien::Nhap();
	cout << "nhap tro cap: ";
	cin >> tro_cap;
	while(cin.fail()){
	   	cin.clear();
	   	cin.ignore(1000,'\n');
	   	cout << "du lieu sai,nhap lai: ";
	   	cin >> tro_cap;
	}
	while(tro_cap < 0){
		cout << "tro cap phai lon hon 0,nhap lai: ";
		cin >> tro_cap;
	}
}

void  NhanVienVanPhong::Xuat()
{
	NhanVien::Xuat();
	cout << "-----thong tin rieng------\n";
	cout <<"tro cap: "<< (size_t)tro_cap << "\n";
}

float  NhanVienVanPhong::TinhLuong()
{
	float luong;
	luong = luong_co_ban + tro_cap;
    return luong;
}
