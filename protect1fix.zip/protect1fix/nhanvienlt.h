#include "nhanvien.h"
#pragma once
#include <iostream>
class LapTrinhVien :public NhanVien
{
    protected:
	    int t_lam_viec;
		int t_ngoai_gio;
		float tro_cap;
		int loai;
	public:	
	     LapTrinhVien()
		{
			loai = 2;
		}
		int LayLoai();	 
		string LayNgaySinh(); 
	    string LayTen(); 
	    void Nhap();
		void Xuat();
		float TinhLuong();
	 
};
