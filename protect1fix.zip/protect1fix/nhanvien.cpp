#include "nhanvien.h"
#include <iomanip>
#include <string.h>
void KiemTraNgay(string ngay,int &k)
{
	int j = 0;
	for(int i  =0;i < ngay.length();i++)
	{
		if(ngay[i] == '/'){
			j = j+1;
		}
	}
	if(j != 2){
		k = 1;
	}
	else{
		char h[ngay.size()];
		copy(ngay.begin(),ngay.end()+1,h);
		int date = atoi(strtok(h,"/"));
		int thang = atoi(strtok(NULL,"/"));
		int nam = atoi(strtok(NULL,"\n"));
		if(nam <= 1950){
			k = 2;
		}
		else if(thang < 1||thang > 12){
			k = 3;
		}
		else if(date < 0||date > 31){
			k = 4;
		}
		else if((date > 28&&thang == 2)){
			k = 5;
		}
		else if(date > 30&&(thang == 4||thang == 6||thang == 9||thang == 11)){
			k = 5;
		}
		else{
			k = 0;
		}
	}	
}

 NhanVien::NhanVien ()
{
	luong_co_ban = 2500000;
}

NhanVien ::~NhanVien ()
{
}

void NhanVien ::Nhap()
{
	cout << "ma: ";
	cin >> ma;
	while(cin.fail()||ma <= 0){
		if (cin.fail()){
		    cin.clear();
		    cin.ignore(1000,'\n');
		    cout << "du lieu sai,nhap lai: ";
		    cin >> ma;	
		}
		else if(ma <= 0){
		   	cout << "ma phai lon hon 0,nhap lai: ";
		   	cin >> ma;
		}
	}
	cin.ignore();
	cout << "nhap ten: ";
	getline(cin,ten);
	while(ten.length() <= 6){
		cout << "ten phai co it nhat 6 ki tu! nhap lai:";
		getline(cin,ten);
	}
	cout << "ngay sinh: ";
	getline(cin,ngay_sinh);
	int k = 0;
	KiemTraNgay(ngay_sinh,k);
	while(k != 0){
		if(k == 1){
		cout << "du lieu phai co dang dd/mm/yyyy,nhap lai: ";
			getline(cin,ngay_sinh);
			KiemTraNgay(ngay_sinh,k);
		}
		else if(k == 2){
			cout<<"nam phai lon 1950, nhap lai: ";
			getline(cin,ngay_sinh);
			KiemTraNgay(ngay_sinh,k);
		}
		else if(k == 3){
			cout<<"thang phai tu 1 den 12,nhap lai: ";
			getline(cin,ngay_sinh);
			KiemTraNgay(ngay_sinh,k);
		}
		else if(k == 4||k == 5){
			cout << "ngay phai lon hon 0 va nho hon so ngay toi da cua thang, nhap lai: ";
			getline(cin,ngay_sinh);
			KiemTraNgay(ngay_sinh,k);
		}
	}
	cout << "email: ";
	getline(cin,email);	
	while(true){
	    size_t t = email.find("@");
		if(t == string::npos){
			cout << "email phai co @,nhap lai : ";
			getline(cin,email);
		}
		else{
		    break;
		}
	}
	cout << "so dien thoai: ";
	cin >> dien_thoai;
	while(cin.fail()||dien_thoai < 0){
		if(cin.fail()){
			cin.clear();
			cin.ignore(1000,'\n');
			cout << "du lieu sai,nhap lai: ";
			cin >> dien_thoai;
		}
		else if(dien_thoai < 0){
			cout << "dien thoai ko the la so am,nhap lai: ";
			cin >> dien_thoai;
		}
	}
	string s = to_string(dien_thoai);
	while(s.length() != 9)
	{
		cout << "so dt phai co 10 so va bat dau bang so 0, nhap lai: ";
		cin >> dien_thoai;
		s = to_string(dien_thoai);
	}
    cin.ignore();
    cout << "dia chi: ";
	getline(cin,dia_chi);
	
}

void NhanVien ::Xuat()
{
	cout << "\n----thong tin chung----- :\n";
	cout << "ma: "<< ma <<"\n";
	cout << "ten: "<< ten <<"\n";
	cout << "ngay sinh: "<<ngay_sinh <<"\n";
	cout << "email: "<< email <<"\n";
	cout << "so dien thoai: "<< 0 <<dien_thoai <<"\n";
	cout << "dia chi: "<< dia_chi <<"\n";
}

int  NhanVien:: LayLoai()
{
}

string  NhanVien::LayNgaySinh()
{
}

string NhanVien::LayTen()
{
}

float NhanVien::TinhLuong()
{
}
