#include <iostream>
#include "nhanvien.h"
#include "nhanvienql.h"
#include "nhanvienlt.h"
#include "nhanvienvp.h"
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void XuatDanhSach(vector <NhanVien *> dsnv)
{
	cout << "\n--------Danh sanh nhan vien quan ly--------\n" << endl;
	for(int i = 0;i < dsnv.size();i++)
	{
		if(dsnv[i]->LayLoai() == 1){
			cout<<"\nnhan vien thu "<<i+1<<"\n";
			dsnv[i]->Xuat();
			cout<<"luong : "<<(size_t)dsnv[i]->TinhLuong();
		 	cout<<"\n";
		}
	}
	cout << "\n--------Danh sanh nhan vien lap trinh--------\n" << endl;
	for(int i = 0;i < dsnv.size();i++)
	{
		if(dsnv[i]->LayLoai() == 2){
			cout<<"\nnhan vien thu "<<i+1<<"\n";
			dsnv[i]->Xuat();
			cout<<"luong : "<<(size_t)dsnv[i]->TinhLuong();
		 	cout<<"\n";
		}
	}
	cout << "\n--------Danh sanh nhan vien van phong--------\n" << endl;
	for(int i = 0;i < dsnv.size();i++)
	{
		if(dsnv[i]->LayLoai() == 3){
			cout<<"\nnhan vien thu "<<i+1<<"\n";
			dsnv[i]->Xuat();
			cout<<"luong : "<<(size_t)dsnv[i]->TinhLuong();
		 	cout<<"\n";
		}
	}
}

void TinhTongLuong(vector <NhanVien *> dsnv)
{
	float luong1 = 0;
	float luong2 = 0;
	float luong3 = 0;
	for(int i = 0;i < dsnv.size();i++)
	{
		if(dsnv[i]->LayLoai() == 1){
		   luong1=luong1+ dsnv[i]->TinhLuong() ; 
		}
		else if(dsnv[i]->LayLoai() == 2){
		   luong2=luong2+ dsnv[i]->TinhLuong() ; 
		}
		else if(dsnv[i]->LayLoai() == 3){
		   luong3=luong3+ dsnv[i]->TinhLuong() ; 
		}
	}
	cout<<"\ntong luong quan ly : "<<(size_t)luong1<<endl;
    cout<<"\ntong luong lap trinh vien : "<<(size_t)luong2<<endl;
    cout<<"\ntong luong van phong : "<<(size_t)luong3<<endl;
    float luong=luong1+luong2+luong3;
    cout<<"\ntong luong toan bo nhan vien : "<<(size_t)luong<<endl;
}
//thuc hien chuc nang nang cao cua bai: sapxep theo ten ,luong,va tim kiem
void SapXepTheoLuong(vector <NhanVien*> &dsnv)
{
    for(int i = 0;i < dsnv.size();i++)
	{
		for(int j = i+1;j < dsnv.size();j++)
		{
			if(dsnv[i]->TinhLuong() >dsnv[j]->TinhLuong() ){
				swap(dsnv[i],dsnv[j]);
			}
		}
	}
}

void SapXepTheoTen(vector <NhanVien*> &dsnv)
{
	for(int i = 0;i < dsnv.size();i++)
	{
		for(int j = i+1;j < dsnv.size();j++)
		{
			if(dsnv[i]->LayTen()>dsnv[j]->LayTen()){
				swap(dsnv[i],dsnv[j]);
			}
		}
	}
}

void DanhSachSauSapXep(vector <NhanVien*> &dsnv)
{
	for(int i = 0;i < dsnv.size();i++)
	{
		cout<<"\n\nnhan vien thu "<<i+1;
		dsnv[i]->Xuat();
		cout<<"luong: "<<(size_t)dsnv[i]->TinhLuong() <<endl;
	}
}

void TimKiemNgaySinh(vector <NhanVien *> dsnv,string ngay_sinh,int &kt)
{
	for(int i = 0;i < dsnv.size();i++)
	{
		if(dsnv[i]->LayNgaySinh() == ngay_sinh){
			dsnv[i]->Xuat();
			cout<<endl;
			kt=1;
		}
	}
}

void MenuInput(vector <NhanVien *> &dsnv) {
	int check;
	do {
		system("cls");
		cout << "\n 1-Nhap thong tin manager.";
		cout << "\n 2-Nhap thong tin programmer.";
		cout << "\n 3-Nhap thong tin officer.";
		cout << "\n 0-Thoat.";
		cout << "\n Lua chon cua ban la: ";
		cin >> check;
		system("cls");
		switch (check) {
			case 1: {
				cout << "\n Ban nhap thong tin manager:\n";
                NhanVien *nv=new NguoiQuanLy;
                nv->Nhap();
                dsnv.push_back(nv);
                system("pause");
				break;
			}
			case 2: {
				cout << "\n Ban nhap thong tin programmer:\n";
			    NhanVien *nv=new LapTrinhVien;
			    nv->Nhap();
			    dsnv.push_back(nv);
				system("pause");
				break;
			}
			case 3: {
				cout << "\n Ban nhap thong tin officer:\n";
				NhanVien *nv=new NhanVienVanPhong;
				nv->Nhap();
				dsnv.push_back(nv);
			    system("pause");
				break;
			}
			case 0: {
				system("pause");
				break;
			}
		}
	} while (check != 0);
}

void Menu() {
    vector <NhanVien *> dsnv;
	int chon;
	do {
		system("cls");
		cout << "\n ========Chuong Trinh Quan Ly Nhan Vien========";
		cout << "\n Moi Ban chon:";
		cout << "\n 1-Nhap thong tin nhan vien.";
		cout << "\n 2-Xem thong tin toan bo nhan vien.";
		cout << "\n 3-Xem thong tin tong luong nhan vien.";
		//thuc hien chuc nang nang cao cua bai: sapxep theo ten ,luong,va tim kiem
		cout << "\n 4-sap xep tang dan theo ten.";
		cout << "\n 5-sap xep tang dan dan theo luong.";
		cout << "\n 6-tim kiem ngay sinh.";
		cout << "\n 0-Thoat.";
		cout << "\n ============================================\n";
		cout << "\n Lua chon cua ban la: ";
		cin >> chon;
		system("cls");
		switch (chon) {
			case 1: {
			    MenuInput(dsnv);
			    system("pause");
				break;
			}
			case 2: {
				cout << "\n--------Danh sanh nhan vien --------\n" << endl;
				XuatDanhSach(dsnv);
				cout << "\n-----------------------------------\n" << endl;
				system("pause");
				break;
			}
			case 3: {
				TinhTongLuong(dsnv);
                system("pause");
				break;
			}
			case 4: {
				cout << "\n--------Danh sanh nhan vien sap xep tang dan theo ten--------\n" << endl;
				SapXepTheoTen(dsnv);
				DanhSachSauSapXep(dsnv);
				cout << "\n-----------------------------------\n" << endl;
				system("pause");
				break;
			}
			case 5: {
				cout << "\n--------Danh sanh nhan vien sap xep tang dan theo luong--------\n" << endl;
				SapXepTheoLuong(dsnv);
				DanhSachSauSapXep(dsnv);
				cout << "\n-----------------------------------\n" << endl;
				system("pause");
				break;
			}
			case 6:{
				cout<<"\nnhap ngay sinh can tim: ";
				string ngay_sinh;
				cin.ignore();
				getline(cin,ngay_sinh);
				int k1 = 0;
				cout<<"\ndanh sach can tim :\n";
				TimKiemNgaySinh(dsnv,ngay_sinh,k1);
				if(k1 == 0){
					cout <<"\nkhong co nhan vien nao can tim!\n";
				}
				system("pause");
				break;
			}
			case 0: {
				cout << "\n Cam on ban da su dung chuong trinh!";
				exit(0);
				system("pause");
				break;
			}		 
		}
	} while (chon != 0);
}

int main(int argc, char** argv) {
    Menu(); 
	return 0;
}
