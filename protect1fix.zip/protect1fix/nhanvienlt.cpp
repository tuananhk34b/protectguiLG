#include "nhanvienlt.h"
int LapTrinhVien::LayLoai()
{
	return loai;
}

string LapTrinhVien::LayNgaySinh()
{
	return ngay_sinh;
}

string  LapTrinhVien::LayTen()
{
    return ten;
}

void LapTrinhVien ::Nhap()
{
	NhanVien::Nhap();
	cout << "thoi gian lam viec: ";
	cin >> t_lam_viec;
	while(cin.fail()){
	cin.clear();
	cin.ignore(1000,'\n');
	cout << "du lieu sai,nhap lai: ";
	cin >> t_lam_viec;
	}
	while(t_lam_viec < 0){
		cout <<"thoi gian phai lon hon 0,nhap lai: ";
		cin >> t_lam_viec;
	}
	cout << "thoi gian ngoai gio: ";
	cin >> t_ngoai_gio;
	while(cin.fail()){
	   	cin.clear();
	   	cin.ignore(1000,'\n');
	   	cout << "du lieu sai,nhap lai: ";
	   	cin >> t_ngoai_gio;
	} 
	while(t_ngoai_gio < 0){
		cout << "thoi gian phai lon hon 0,nhap lai: ";
		cin >> t_ngoai_gio;
	}
	cout << "tro cap: ";
	cin >> tro_cap;
	while(cin.fail()){
	cin.clear();
	cin.ignore(1000,'\n');
	cout << "du lieu sai,nhap lai: ";
	cin >> tro_cap;
	} 
	while(tro_cap < 0){
		cout << "tro cap phai lon hon 0,nhap lai: ";
		cin >> tro_cap;
	}
}

void  LapTrinhVien::Xuat()
{
	NhanVien::Xuat();
	cout << "-----thong tin rieng----\n";
	cout << "thoi gian lam viec: "<<t_lam_viec<<"\n";
	cout << "thoi gian ngoai gio: "<<t_ngoai_gio<<"\n";
	cout << "tro cap: "<<(size_t)tro_cap<<"\n";
}

float  LapTrinhVien::TinhLuong()
{
	float luong;
	luong=luong_co_ban + (luong_co_ban/t_lam_viec)*t_ngoai_gio*1.5 + tro_cap;
	return luong;
}
