#include <string>
#pragma once
#include <iostream>
using namespace std;
class NhanVien
{
    protected:
    	int ma;
    	string ten;
    	string ngay_sinh;
    	string email;
    	long int dien_thoai;
    	string dia_chi;
    	long int luong_co_ban;
	public:	
	    NhanVien();
	    ~NhanVien();
	    virtual int LayLoai();
	    virtual string LayNgaySinh();
	    virtual string LayTen();
	    virtual void Nhap();  
	    virtual void Xuat();
        virtual float TinhLuong();   
};
