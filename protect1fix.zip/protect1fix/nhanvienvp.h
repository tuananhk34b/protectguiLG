#include "nhanvien.h"
#pragma once
#include <iostream>
class NhanVienVanPhong :public NhanVien
{
    protected:
    	float tro_cap;
    	int loai;
	public:	
	    NhanVienVanPhong()
		{
			loai = 3;
		}
		int LayLoai(); 
		string LayNgaySinh(); 
		string LayTen();
	    void Nhap();
		void Xuat(); 
	    float TinhLuong();	 
};

