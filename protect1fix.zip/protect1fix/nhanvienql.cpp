#include "nhanvienql.h"
int  NguoiQuanLy::LayLoai()
{
	return loai;
}

string NguoiQuanLy ::LayNgaySinh()
{
	return ngay_sinh;
}

string  NguoiQuanLy::LayTen()
{
	return ten;
}

void  NguoiQuanLy::Nhap()
{
	NhanVien::Nhap();
	cin.ignore();
	cout<<"chuc vu: ";
	getline(cin,chuc_vu);
	cout << "he so cv: ";
	cin >> he_so_cv;
		while(cin.fail()||he_so_cv < 0){
		    if(cin.fail()){
			    cin.clear();
	   	   	    cin.ignore(1000,'\n');
	   	   	    cout << "du lieu sai,nhap lai: ";
	   	   	    cin >> he_so_cv;
		   }
	   	    else if(he_so_cv < 0){
	   	   	    cout << "he so phai lon hon 0: ";
	   	   	    cin >> he_so_cv;
			}
		}
	cout << "thuong: ";
	cin >> thuong;
    while(cin.fail()||thuong < 0){
		if(cin.fail()){
			cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout << "du lieu sai,nhap lai: ";
		   	cin >> thuong;
		}
	   	else if(thuong < 0){
	   	   	cout << "thuong ko the la so am, nhap lai: ";
	   	   	cin >> thuong;
		}
	}
}

void NguoiQuanLy ::Xuat()
{
	NhanVien::Xuat();
	cout << "\n-----thong tin rieng----\n";
	cout << "chuc vu: "<< chuc_vu <<"\n";
	cout << "he so sv: "<< he_so_cv <<"\n";
	cout << "thuong: "<< (size_t)thuong <<"\n";
}

float NguoiQuanLy ::TinhLuong()
{
	float luong;
	luong = luong_co_ban + (luong_co_ban*he_so_cv) + thuong;
	return luong;
}
 
