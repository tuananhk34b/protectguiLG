#include <string>
#include <iostream>
#include "nhanvien.h"
#pragma once
using namespace std;
class NguoiQuanLy :public NhanVien
{
	protected:
		string chuc_vu;
		float he_so_cv;
		float thuong;
		int loai;
	public:
		NguoiQuanLy()
		{
			loai = 1;
		}
		int LayLoai();
		string LayNgaySinh();	 
		string LayTen();
	    void Nhap();
		void Xuat(); 
		float TinhLuong();
	 
};
