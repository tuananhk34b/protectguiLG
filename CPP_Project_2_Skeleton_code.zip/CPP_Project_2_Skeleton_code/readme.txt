IDE :protect nay duoc viet tren dev C phien ban 5.11
cac tinh nang nang cao da cai dat: kiem tra du lieu nhap vao c� d�ng kh�ng,
                                   Th�m thuat toan sap xep moi :them interchangesort
                                   them chuc nang tim kiem