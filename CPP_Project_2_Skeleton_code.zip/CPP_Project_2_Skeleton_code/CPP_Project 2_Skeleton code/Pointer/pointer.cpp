#include <iostream>
using namespace std;
//ung dung nay viet tren dev c phien ban 5.11
// Hoan doi gia tri hai bien
void Swap(int *num1, int *num2)
{
	if(*num1 > *num2){
		int *tem = new int;
		*tem = *num1;
		*num1 = *num2;
		*num2 = *tem;
	}	
	//your code here
}

// In mang
void PrintArray(int *arr, int n)
{
	//your code here
	for(int i =  0;i < n;i++)
	{
		cout<<arr[i]<<"\t";
	}
}

// Thuat toan sap xep noi bot
void BubbleSort(int *arr, int n)
{
	int i, j;
	for (i = 0; i < n-1; i++)
	{
		for (j = n-1; j > i; j--)
		{
			Swap((arr+j-1),(arr+j));
		}
	}
}
// Thuat toan sap xep chon

void SelectionSort(int *arr, int n)
{
	int min;
	for(int i = 0;i < n;i++)
	{
		min=i;/*tim phan tu nho nhat cua mang, gia su nho nhat la *(arr+i)*/
		for(int j = i + 1;j < n;j++)
		{
			if(*(arr+j) < *(arr+min))
			 min = j;//gan min=j neu *(arr+j) nho hon
		}
		if(min != i)
		{
			Swap((arr+i),(arr+min));// hoan doi vi tri neu *(arr+i) ko phai nho nhat
		}
	}
}
//thuc hien yeu cau nang cao cua de bai, them interchangesort;

void InterchangeSort(int *arr, int n)
{
	for(int i = 0;i < n;i++)
	{
		for(int j = i + 1;j < n;j++)
		{
			Swap((arr+i),(arr+j));
		}
	}
}
//thuc hien yeu cau nang cao cua de bai , them chuc nang tim kiem

void TimKiem(int *arr, int n,int &k,int m)
{
	for(int i = 0;i < n;i++)
	{
		if(*(arr+i) == m){
		  k = k + 1;
		}
	}
}
int main()
{
	int arr[10]; // Mang dau vao
	int i;
	int n; // Kich thuoc mang
	int menu_option;

	cout << "Kich thuoc mang: ";
	//your code here
	cin>>n;

	cout << endl << "Nhap mang dau vao: " << endl;
	//your code here
	int *arr1 = arr;
	for(int i = 0;i < n;i++)
	{
		cout<<"arr["<<i<<"] = ";
		cin>>arr1[i];
		//thuc hien yeu cau nang cao ,kiem tra du lieu khong phai so
		while(cin.fail()){
	    	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"du lieu sai,nhap lai: ";
		   	cin>>arr1[i];
	    }
	}
	cout << endl << "Mang truoc khi sap xep: " << endl;
	//your code here
    PrintArray(arr1,n);
	cout << endl;
    

	do {
		cout<<"\nvui long chon thuat toan sap xep ";
		cout<<"\n 1. thuat toan noi bot(bubble)";
		cout<<"\n 2. thuat toan chon(selection)";
		//thuc hien yeu cau nang cao cua de bai, them interchangesort;
		cout<<"\n 3. thuat toan sap xep doi cho truc tiep(interchange)";
		//thuc hien yeu cau nang cao cua de bai , them chuc nang tim kiem
		cout<<"\n 4. tim kiem trong mang ";
		//your code here;
		cin>> menu_option;
	} while (menu_option != 1 && menu_option != 2 && menu_option != 3 && menu_option != 4);
	switch (menu_option) {
		case 1:
			//your code here
			BubbleSort(arr1,n);
			break;
		case 2:
			//your code here
			SelectionSort(arr1,n);
			break;
		case 3:
			InterchangeSort(arr1,n);
			break;
		case 4:
			cout<<"nhap phan tu can tim: \n";
			int m;
			cin>>m;
			int k = 0;
			TimKiem(arr,n,k,m);
			if (k == 0){
				cout<<"\nko tim thay phan tu can tim!";
			}
			else{
				cout<<"\nthay "<<m<<" xuat hien "<<k<<" lan trong mang!";
			}
			break;
	}
    if (menu_option == 1 || menu_option == 2 || menu_option == 3){
    	cout << endl << "Mang sau khi sap xep: " << endl;
	    PrintArray(arr1,n);
	}
	//your code here	 
	return 0;
}
