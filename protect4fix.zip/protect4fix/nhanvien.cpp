#include "nhanvien.h"
NhanVien::NhanVien()
{
	ten_nhan_vien = "";
    ho_nhan_vien = "";
	chuc_danh_cv = "";
	phong_ban = "";
	luong_hn = 0;
	luong_hn_sau_np = 0;
}
NhanVien::~NhanVien(){};
void  NhanVien::SetTenNhanVien(string ten)
{
	ten_nhan_vien = ten;
}

void  NhanVien::SetHoNhanVien(string ho)
{
	ho_nhan_vien = ho;
}

void NhanVien::SetChucDanhCV(string cv)
{
	chuc_danh_cv = cv;
}

void  NhanVien::SetPhongBan(string pb)
{
	phong_ban = pb;
}

void  NhanVien::SetLuongHN(int luong)
{
	luong_hn = luong;
}

void  NhanVien::SetLuongHNSauNP(int luong)
{
	luong_hn_sau_np = luong;
} 

string  NhanVien::LayTenNhanVien()
{
	return ten_nhan_vien;
}

string  NhanVien::LayHoNhanVien()
{
	return ho_nhan_vien;
}

string  NhanVien::LayChucDanhCV()
{
	return chuc_danh_cv;
}

string  NhanVien::LayPhongBan()
{
	return phong_ban;
}

int  NhanVien::LayLuongHN()
{
	return luong_hn;
}

int  NhanVien::LayLuongHNSauNP()
{
	return luong_hn_sau_np;
}

void NhanVien::Xuat()
{
	cout<<setw(16)<<ten_nhan_vien<<setw(16)<<ho_nhan_vien<<setw(48)<<chuc_danh_cv;
	cout<<setw(22)<<phong_ban<<setw(10)<<luong_hn<<setw(10)<<luong_hn_sau_np<<endl;
}
