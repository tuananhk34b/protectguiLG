#include <iostream>
#include "nhanvien.h"
#include <vector>
#include <fstream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// lufile chua  danh da sap xep
void LuuFile(vector<NhanVien> dsnvcd)
{
	ofstream fileluu1("Employees_Job_Title.csv");
	fileluu1<<"FIRSTNAME,LASTNAME,JOB TITLE,DEPARTMENT,EMPLOYEE ANNUAL SALARY,ESTIMATED ANNUAL SALARY MINUS FURLOUGHS,\n";
	for(int i=0;i<dsnvcd.size();i++)
	{
	    NhanVien *nv = &dsnvcd[i];
	    fileluu1<<nv->LayTenNhanVien();
	    fileluu1<<",";
	    fileluu1<<nv->LayHoNhanVien();
	    fileluu1<<",";
	    fileluu1<<nv->LayChucDanhCV();
	    fileluu1<<",";
	    fileluu1<<nv->LayPhongBan();
	    fileluu1<<",";
	    fileluu1<<nv->LayLuongHN();
	    fileluu1<<",";
	    fileluu1<<nv->LayLuongHNSauNP();
	    fileluu1<<"\n";   
	}
	fileluu1.close();
}
// luufile phong ban da sap xep
void LuuFile1(vector<NhanVien> dsnvpb)
{
	ofstream fileluu2("Employees_Department.csv");
	fileluu2<<"FIRSTNAME,LASTNAME,JOB TITLE,DEPARTMENT,EMPLOYEE ANNUAL SALARY,ESTIMATED ANNUAL SALARY MINUS FURLOUGHS,\n";
	for(int i=0;i<dsnvpb.size();i++)
	{
	    NhanVien *nv = &dsnvpb[i];
	    fileluu2<<nv->LayTenNhanVien();
	    fileluu2<<",";
	    fileluu2<<nv->LayHoNhanVien();
	    fileluu2<<",";
	    fileluu2<<nv->LayChucDanhCV();
	    fileluu2<<",";
	    fileluu2<<nv->LayPhongBan();
	    fileluu2<<",";
	    fileluu2<<nv->LayLuongHN();
	    fileluu2<<",";
	    fileluu2<<nv->LayLuongHNSauNP();
	    fileluu2<<"\n";   
	}
	fileluu2.close();
}
// doc file csv
void DocFile(NhanVien dsnv[],int &n)
{
	ifstream fileluu("Employees.csv");
	string h,h1,h2;
	string ten_nhan_vien,ho_nhan_vien,chuc_danh_cv,phong_ban;
	int luong_hn, luong_hn_sau_np;
	getline(fileluu,h,'\n');
	int i=0;
    while(!fileluu.eof()){
    	getline(fileluu,ten_nhan_vien,',');
    	getline(fileluu,ho_nhan_vien,',');
    	getline(fileluu,chuc_danh_cv,',');
    	getline(fileluu,phong_ban,',');
        getline(fileluu,h1,',');
        char c[h1.size()];
        copy(h1.begin(),h1.end(),c);
        luong_hn=atoi(c);
        getline(fileluu,h2,'\n');
        char c2[h2.size()];
        copy(h2.begin(),h2.end(),c2);
        luong_hn_sau_np=atoi(c2);
        NhanVien nv;
        nv.SetTenNhanVien(ten_nhan_vien);
        nv.SetHoNhanVien(ho_nhan_vien);
        nv.SetChucDanhCV(chuc_danh_cv);
        nv.SetPhongBan(phong_ban);
        nv.SetLuongHN(luong_hn);
        nv.SetLuongHNSauNP(luong_hn_sau_np);
    	if(fileluu.eof())
		{
			break;
		}
	    dsnv[i] = nv;
	    i++;
	}
	fileluu.close();
	n = i;
}

void XuatDanhSach(NhanVien dsnv[],int n)
{
	for(int i = 0;i < n;i++)
	{
		dsnv[i].Xuat();
	}
}
// tim kiem tuyen tinh chuc danh
void TimKiemChucDanh(NhanVien dsnv[],vector<NhanVien> &dsnvcd,int n,string chuc_danh)
{
	int k = 0;
	for(int i = 0;i < n;i++)
	{
		if(dsnv[i].LayChucDanhCV() == chuc_danh){
			dsnv[i].Xuat();
		    dsnvcd.push_back(dsnv[i]);
			k = 1;
		}
	}
 
	if(k == 1){
		cout<<"\nday la danh sach can tim!\n";
	}
	else{
		cout<<"\nko tim thay chuc danh nay!\n";
	} 
}
//sap xep phong ban truoc khi tim kiem nhi phan
void SortPhongBan(NhanVien dsnv[],int n)
{
	for(int i = 0;i < n;i++)
	{
	    for(int j = i+1;j < n;j++)
	    {
	    	if(dsnv[i].LayPhongBan() < dsnv[j].LayPhongBan()){
	    		swap(dsnv[i],dsnv[j]);
			}
		}
	}
}
// tim kiem nhi phan phong ban
void TimKiemPhongBan(NhanVien dsnv[],vector<NhanVien> &dsnvpb,int n,string pb)
{
	int left = 0;
	int right = n-1;
	int mid = 0;
	int k = 0; 
	do
	{ 
	    mid = (left+right)/2;
	    if(dsnv[mid].LayPhongBan() == pb){
	      	k = 1;
	      	for(int i = mid;i < n;i++)
	      	{
	      		if(dsnv[i].LayPhongBan() == pb){
	      			dsnv[i].Xuat();
	      			dsnvpb.push_back(dsnv[i]);
				}
			}
			for(int j = mid-1;j >= 0;j--)
			{
				 if(dsnv[j].LayPhongBan() == pb){
	      			dsnv[j].Xuat();
	      			dsnvpb.push_back(dsnv[j]);
				}
			}
			break;
		}
		else if(dsnv[mid].LayPhongBan() < pb){
			right = mid-1;
		}
		else{
			left = mid-1;
		}
		
	}while(left < right);
	if(k == 1){
		cout<<"\nday la danh sach can tim\n";
	}
	else{
		cout<<"\nko tim thay phong ban can tim\n";
	}
}
//sap xep thep luong
void SortTheoLuong(NhanVien dsnv[],int n)
{
	int pos = 0;
	NhanVien nv;
	for(int i = 1;i < n;i++)
	{
		nv = dsnv[i];
		for(pos = i;(pos > 0&&dsnv[pos-1].LayLuongHN() > nv.LayLuongHN());pos--)
		{
			dsnv[pos] = dsnv[pos-1];
		}
		dsnv[pos] = nv;
	}
}
// sap theo ten
void SortTheoTen(NhanVien dsnv[],int left,int right)
{
	if(left >= right)return;
	NhanVien pivot = dsnv[(left+right)/2];
	int i = left,j = right;
	do
	{
		while(dsnv[i].LayTenNhanVien() < pivot.LayTenNhanVien())i++;
		while(dsnv[j].LayTenNhanVien() > pivot.LayTenNhanVien())j--;
		if(i <= j){
			NhanVien nv = dsnv[i];
			dsnv[i] = dsnv[j];
			dsnv[j] = nv;
			i++;
			j--;
		}		
	}while(i < j);
	SortTheoTen(dsnv,left,j);
	SortTheoTen(dsnv,i,right);
}
//sap xep phong ban
void Merge(NhanVien dsnv[],int left,int mid,int right)
{
	int ntemp = right - left + 1;
	NhanVien temp[ntemp];
	int pos = 0;
	int i = left;
	int j = mid + 1;
	while(!(i > mid&&j > right)){
	    	if((i <= mid&&i <= right&&dsnv[i].LayPhongBan() < dsnv[j].LayPhongBan())||j > right)
		     temp[pos++]=dsnv[i++];
		    else
		     temp[pos++] = dsnv[j++];
	}
	for(int i = 0;i < ntemp;i++)
	{ 
		dsnv[left+i] = temp[i];
	}
}

void SortPhongBan(NhanVien dsnv[],int left,int right)
{
	if(left >= right)return;
	int mid = (left + right)/2;
	SortPhongBan(dsnv,left,mid);
	SortPhongBan(dsnv,mid + 1,right);
	Merge(dsnv,left,mid,right);
}

void SortChucDanh(NhanVien dsnv[],int n)
{
	for(int i = 0;i < n;i++)
	{
		for(int j = i + 1;j < n;j++)
		{
			if(dsnv[i].LayChucDanhCV() > dsnv[j].LayChucDanhCV()){
				NhanVien nv=dsnv[i];
			    dsnv[i] = dsnv[j];
			    dsnv[j] = nv;
			}
		}
	}
}
//chuc nang nang cao cua de bai:
void SortNangCaoTheoTen(NhanVien dsnv[],int n)
{
	for(int i = 0;i < n;i++)
	{
		for(int j = i+1;j < n;j++)
		{
			if(dsnv[i].LayTenNhanVien() > dsnv[j].LayTenNhanVien()){
				swap(dsnv[i],dsnv[j]);
			}
			if(dsnv[i].LayTenNhanVien() == dsnv[j].LayTenNhanVien()&&dsnv[i].LayHoNhanVien() > dsnv[j].LayHoNhanVien()){
				swap(dsnv[i],dsnv[j]);
			}
		}
	}
}
//luufile sap sep
void LuuFilesx(NhanVien dsnv[],int n)
{
	ofstream fileluu3("Employees_Sorted.csv");
	fileluu3<<"FIRSTNAME,LASTNAME,JOB TITLE,DEPARTMENT,EMPLOYEE ANNUAL SALARY,ESTIMATED ANNUAL SALARY MINUS FURLOUGHS,\n";
	for(int i = 0;i < n;i++)
	{
	    NhanVien nv = dsnv[i];
	    fileluu3<<nv.LayTenNhanVien();
	    fileluu3<<",";
	    fileluu3<<nv.LayHoNhanVien();
	    fileluu3<<",";
	    fileluu3<<nv.LayChucDanhCV();
	    fileluu3<<",";
	    fileluu3<<nv.LayPhongBan();
	    fileluu3<<",";
	    fileluu3<<nv.LayLuongHN();
	    fileluu3<<",";
	    fileluu3<<nv.LayLuongHNSauNP();
	    fileluu3<<"\n";   
	}
	fileluu3.close();
}

void MenuSort(NhanVien dsnv[],int n) {
	int check;
	do {
		cout << "\n ========Sap xep thong tin========";
		cout << "\n Moi Ban chon:";
		cout << "\n 1-Theo luong hang nam.";
		cout << "\n 2-Theo ten nhan vien.";
		cout << "\n 3-Theo chuc danh.";
		cout << "\n 4-Theo phong ban.";
		cout << "\n 5-Thuc hien chuc nang nang cao .sap xep theo ten va xuat ra csv moi.";
		cout << "\n 0-Thoat.";
		cout << "\n ============================================" << endl;
		cout << "\n Lua chon cua ban la: ";
		cin >> check;
		switch (check) {
			case 1: {
				cout<<"\ninsertion sort tang dan theo luong:\n";
				SortTheoLuong(dsnv,n);
				XuatDanhSach(dsnv,n);
				system("pause");
				break;
			}
			case 2: {
				cout<<"\n quick sort tang dan theo ten\n";
				SortTheoTen(dsnv,0,n-1);
				XuatDanhSach(dsnv,n);
				system("pause"); 
				break;
			}
			case 3: {
				cout<<"\n interchange sort tang dan theo chuc danh\n";
				SortChucDanh(dsnv,n);
				XuatDanhSach(dsnv,n);
				system("pause"); 
				break;
			}
			case 4: {
				cout<<"\n merge sort tang dan theo phong ban\n";
				SortPhongBan(dsnv,0,n-1);
				XuatDanhSach(dsnv,n);
			    system("pause");
				break;
			}
			case 5:{
				//chuc nang nang coa ,sap sep theo ten, ho ,luu csv moi
				SortNangCaoTheoTen(dsnv,n);
				XuatDanhSach(dsnv,n);
				LuuFilesx(dsnv,n);
				cout<<"\nda luu file csv\n";
				system("pause");
				break;
			}
			case 0: {
				system("cls");
				break;
			}
		}
		 
	} while (check != 0);
}

void MenuSearch(NhanVien dsnv[],int n) {
	int m = 2000;
    vector<NhanVien> dsnvcd;
    vector<NhanVien> dsnvpb;
	int check;
	do {
		cout << "\n ========Tim kiem========";
		cout << "\n Moi Ban chon:";
		cout << "\n 1-Chuc danh.";
		cout << "\n 2-Phong ban.";
		cout << "\n 0-Thoat.";
		cout << "\n ============================================" << endl;
		cout << "\n Lua chon cua ban la: ";
		cin >> check;
		switch (check) {
			case 1: {
				cout<<"nhap chuc danh muon tim: ";
				string danh;
				cin.ignore();
				getline(cin,danh);
				TimKiemChucDanh(dsnv,dsnvcd,n,danh);   
				cout<<"file da luu:\n";
				LuuFile(dsnvcd);
			    system("pause");
				break;
			}
			case 2: {
				SortPhongBan(dsnv,n);
				cout<<"nhap phong ban muon tim: ";
				string pb;
				cin.ignore();
				getline(cin,pb);
			    TimKiemPhongBan(dsnv,dsnvpb,n,pb);
				LuuFile1(dsnvpb);
			    cout<<"file da luu: \n";
			    system("pause");
				break;
			}
			case 0: {
			    system("cls");
				break;
			}
			 
		}
		 
	} while (check != 0);
}

void Menu(NhanVien dsnv[],int n) {
    
	int ck;
	do {
		cout << "\n ========Chuong Trinh Quan Ly Luong Nhan Vien========";
		cout << "\n Moi Ban chon:";
		cout << "\n 1-Hien thi.";
		cout << "\n 2-Tim kiem.";
		cout << "\n 3-Sap xep.";
		cout << "\n 0-Thoat.";
		cout << "\n ============================================\n";
		cout << "\n Lua chon cua ban la: ";
		cin >> ck;
		system("cls");
		switch (ck) {
		case 1: {
			cout<<"danh sach can hien thi: \n";
			XuatDanhSach(dsnv,n);
			system("pause");
			break;
		}
		case 2: {
		    MenuSearch(dsnv,n);
		    system("pause");
			break;
		}
		case 3: {
			MenuSort(dsnv,n);
			system("pause");
			break;
		}
		case 0: {
			cout << "\n Cam on ban da su dung chuong trinh!";
			exit(0);
			break;
		}
    }  
	} while (ck != 0);
}

int main(int argc, char** argv) {
	int n = 10000;
	NhanVien dsnv[n];
	DocFile(dsnv,n);
	Menu(dsnv,n);
	return 0;
}
