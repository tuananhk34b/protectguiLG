#include <string>
#include <iostream>
#include <iomanip>
using namespace std;
class NhanVien
{
	protected:
		string ten_nhan_vien;
		string ho_nhan_vien;
		string chuc_danh_cv;
		string phong_ban;
		int luong_hn;
		int luong_hn_sau_np;
	public:
		NhanVien();
		~NhanVien();
		void SetTenNhanVien(string);
		void SetHoNhanVien(string);	 
		void SetChucDanhCV(string);	 
		void SetPhongBan(string);  
		void SetLuongHN(int);	 
		void SetLuongHNSauNP(int);	 
		string LayTenNhanVien();
		string LayHoNhanVien();
		string LayChucDanhCV();	 
		string LayPhongBan();
		int LayLuongHN();
		int LayLuongHNSauNP();	 
		void Xuat();
};
