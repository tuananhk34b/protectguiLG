#include "nhanvienlt.h"
long int LapTrinhVien::LayLuongCoBan()
{
    return luong_co_ban;
}

int LapTrinhVien::LayMa()
{
	return ma;
}

string LapTrinhVien ::LayTen()
{
	return ten;
}

string  LapTrinhVien::LayEmail()
{
	return email;
}

long int  LapTrinhVien::LayDienThoai()
{
	return dien_thoai;
}

string  LapTrinhVien::LayDiaChi()
{
	return dia_chi;
}

string  LapTrinhVien::LayNgaySinh()
{
	return ngay_sinh;
}

void  LapTrinhVien::SetMa(int ma1)
{
	ma = ma1;
}

void  LapTrinhVien::SetTen(string ten1)
{
    ten = ten1;
}

void LapTrinhVien ::SetEmail(string mail)
{
	email = mail;
}

void  LapTrinhVien::SetNgaySinh(string ngay_sinh1)
{
	ngay_sinh = ngay_sinh1;
}

void  LapTrinhVien::SetDienThoai(long int dt)
{
	dien_thoai = dt;
}

void  LapTrinhVien::SetDiaChi(string dc)
{
	dia_chi = dc;
}

void  LapTrinhVien::SetTLamViec(int t)
{ 
	t_lam_viec = t;
}

void  LapTrinhVien::SetTNgoaiGio(int t)
{
	t_ngoai_gio = t;
}

void  LapTrinhVien::SetTroCap(int tc)
{
	tro_cap = tc;
}

int  LapTrinhVien::LayTLamViec()
{
	return t_lam_viec;
}

int  LapTrinhVien::LayTNgoaiGio()
{
    return t_ngoai_gio;
}

float  LapTrinhVien::LayTroCap()
{
	return tro_cap;
}

 LapTrinhVien::LapTrinhVien()
{
	loai = 2;
}

int  LapTrinhVien::LayLoai()
{
	return loai;
}

//ham xu ly ngoai le
void NgoaiLe2(int so)
{
	try{
		if(so < 0)
		  throw so;
	}
	catch(int so){
	    cout << "du lieu so khong the nho hon 0,nhap lai : "; 
	}
}

void  LapTrinhVien::Nhap()
{
	NhanVien::Nhap();
	cout << "thoi gian lam viec: ";
	cin >> t_lam_viec;
	while(cin.fail()){
	   	cin.clear();
	   	cin.ignore(1000,'\n');
	   	cout << "du lieu sai,nhap lai: ";
	   	cin >> t_lam_viec;
	}
	while(t_lam_viec < 0){
		NgoaiLe2(t_lam_viec);
		cin >> t_lam_viec;
	}
	cout << "thoi gian ngoai gio: ";
	cin >> t_ngoai_gio;
	while(cin.fail()){
	   	cin.clear();
	   	cin.ignore(1000,'\n');
	   	cout << "du lieu sai,nhap lai: ";
	   	cin >> t_ngoai_gio;
	} 
	while(t_ngoai_gio < 0){
		NgoaiLe2(t_ngoai_gio);
		cin >> t_ngoai_gio;
	}
	cout << "tro cap: ";
	cin >> tro_cap;
	while(cin.fail()){
	cin.clear();
	cin.ignore(1000,'\n');
	cout << "du lieu sai,nhap lai: ";
	cin >> tro_cap;
	} 
	while(tro_cap < 0){
	    NgoaiLe2(tro_cap);
		cin >> tro_cap;
	}
}

void LapTrinhVien::Xuat()
{
	NhanVien::Xuat();
	cout << "-----thong tin rieng----\n";
	cout << "thoi gian lam viec: " << t_lam_viec << "\n";
	cout << "thoi gian ngoai gio: "<< t_ngoai_gio << "\n";
	cout << "tro cap: "<< (size_t)tro_cap << "\n";
}

float LapTrinhVien::TinhLuong()
{
	float luong;
	luong=luong_co_ban + (luong_co_ban/t_lam_viec)*t_ngoai_gio*1.5 + tro_cap;
	return luong;
}
