
#include "nhanvien.h"
#pragma once
class QuanLy :public NhanVien
{
	protected:
		string chuc_vu;
		float he_so_cv;
		float thuong;
		int loai;
	public:
	    long int LayLuongCoBan();
		int LayMa();
		string LayTen();	 
		string LayEmail();
		long int LayDienThoai();
		string LayDiaChi();
		string LayNgaySinh();
		void SetMa(int); 
	    void SetTen(string);	 
		void SetEmail(string);
		void SetNgaySinh(string);
	    void SetDienThoai(long int);
	    void SetDiaChi(string);
	    void SetChucVu(string);
		void SetHeSoCV(float);
		void SetThuong(float);
	    string LayChucVu();
		float LayHeSoCV();
		float LayThuong();	 
		QuanLy();
		int LayLoai();
		void Nhap(); 
	    void Xuat();  
		float TinhLuong();	 
};
