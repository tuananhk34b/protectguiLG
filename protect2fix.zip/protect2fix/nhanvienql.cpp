#include "nhanvienql.h"
long int QuanLy::LayLuongCoBan()
{
	return luong_co_ban;
}

int QuanLy::LayMa()
{
	return ma;
}

string QuanLy ::LayTen()
{
    return ten;
}

string  QuanLy::LayEmail()
{
	return email;
}

long int  QuanLy::LayDienThoai()
{
	return dien_thoai;
}

string QuanLy::LayDiaChi()
{
	return dia_chi;
}

string  QuanLy::LayNgaySinh()
{
	return ngay_sinh;
}

void  QuanLy::SetMa(int ma1)
{
	ma = ma1;
}

void QuanLy ::SetTen(string ten1)
{
	ten = ten1;
}
void  QuanLy::SetEmail(string mail)
{
	email = mail;
}

void  QuanLy::SetNgaySinh(string ngay_sinh1)
{
    ngay_sinh = ngay_sinh1;
}

void  QuanLy::SetDienThoai(long int dt)
{
	dien_thoai = dt;
}

void QuanLy ::SetDiaChi(string dc)
{
	dia_chi = dc;
}

void  QuanLy::SetChucVu(string cv)
{
	chuc_vu = cv;
}

void QuanLy ::SetHeSoCV(float he_so)
{
	he_so_cv = he_so;
}

void  QuanLy::SetThuong(float thuong1)
{
	thuong = thuong1;
}

string  QuanLy::LayChucVu()
{
	return chuc_vu;
}

float QuanLy ::LayHeSoCV()
{
	return he_so_cv;
}

float  QuanLy::LayThuong()
{
	return thuong;
}

int  QuanLy ::LayLoai()
{
	return loai;
}

void NgoaiLe1(int so)
{
	try{
		if(so<0)
		  throw so;
	}
	catch(int so){
	    cout << "du lieu so khong the nho hon 0,nhap lai : "; 
	}
}

void  QuanLy::Nhap()
{
	NhanVien::Nhap();
	cin.ignore();
	cout << "chuc vu: ";
	getline(cin,chuc_vu);
	cout << "he so cv: ";
	cin >> he_so_cv;
	while(cin.fail()||he_so_cv < 0){
		if(cin.fail()){
			cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout << "du lieu sai,nhap lai: ";
		   	cin >> he_so_cv;
		}
	   	else if(he_so_cv < 0){
	   	    NgoaiLe1(he_so_cv);
			cin >> he_so_cv;
		}
	}
	cout << "thuong: ";
	cin >> thuong;
	while(cin.fail()||thuong < 0){
		if(cin.fail()){
			cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout << "du lieu sai,nhap lai: ";
		   	cin >> thuong;
		}
	   	else if(thuong < 0){
	   	   	NgoaiLe1(thuong);
	   	   	cin >> thuong;
		}
	}
}

void QuanLy ::Xuat()
{
	NhanVien::Xuat();
	cout << "\n-----thong tin rieng----\n";
	cout << "chuc vu: " << chuc_vu << "\n";
	cout << "he so sv: " <<he_so_cv << "\n";
	cout << "thuong: " << (size_t)thuong << "\n";
}

float QuanLy ::TinhLuong()
{
	float luong;
	luong = luong_co_ban + (luong_co_ban*he_so_cv) + thuong;
    return luong;
}

QuanLy:: QuanLy()
{
	loai = 1;
}

