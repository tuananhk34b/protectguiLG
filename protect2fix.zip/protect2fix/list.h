#include <iostream>
template <class T>
class List
{
	private:
	    T dsnv[1000];
	    int i=0;
	public:
		//ham khoi tao gia tri
		List()
		{
			for(int i = 0;i < 1000;i++)
			{
				dsnv[i] = NULL;
			}
		}
	    //them phan tu
		void Add(T nv)
		{
			 dsnv[i]=nv;
			 i++;
		}
		// tinh so phan tu
		int Size()
		{
			return i;
		}
		//lay gia tri 1 phan tu cua mang
		T LayGiaTri(int n)
		{
			return dsnv[n];
		}
		
		//cai dat gia tri 1 phan tu cua mang
		void SetGiaTri(int n,T nv)
		{
		    dsnv[n] = nv;
		}
};
