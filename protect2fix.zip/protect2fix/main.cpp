#include <iostream>
#include "nhanvien.h"
#include "nhanvienql.h"
#include "nhanvienlt.h"
#include "nhanvienvp.h"
#include "list.h"
#include <fstream>
#include <string.h>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

//cac ham xu ly ngoai le voi docfile
//ham kiem tra ngay

void KiemTraNgay1(string ngay,int &k)
{
	int j = 0;
	for(int i = 0;i< ngay.length();i++)
	{
		if(ngay[i] == '/'){
			j = j+1;
		}
	}
	if(j != 2){
		k = 1;
	}
	else{
		char h[ngay.size()];
		copy(ngay.begin(),ngay.end()+1,h);
		int date = atoi(strtok(h,"/"));
		int thang = atoi(strtok(NULL,"/"));
		int nam = atoi(strtok(NULL,"\n"));
		if(nam <= 1950){
			k = 1;
		}
		else if(thang < 1||thang > 12){
			k = 1;
		}
		else if(date < 0||date > 31){
			k = 1;
		}
		else if((date>28&&thang==2)){
			k = 1;
		}
		else if((date > 30)&&(thang==4||thang==6||thang==9||thang==11)){
			k = 1;
		}
	}	
}

void NgoaiLeSo1(int so,int &kt)
{	 
	if(so < 0)
	  kt = 1;
}

void NgoaiLeDT1(int t,int&kt)
{
	if(t != 9)
	   kt = 1;
}
//thuc hien chuc nang nang cao, tim luong max,min,

void TimLuongMax(List <NhanVien *> danhsach)
{
	float max = 0;
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i)->TinhLuong() > max){
		   max = danhsach.LayGiaTri(i)->TinhLuong(); 
		}
	}
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i)->TinhLuong() == max){
		   danhsach.LayGiaTri(i)->Xuat();
		   cout<<"luong : "<<(size_t)danhsach.LayGiaTri(i)->TinhLuong();
		}
	}
}

void TimLuongMin(List <NhanVien *> danhsach)
{
	float min = danhsach.LayGiaTri(0)->TinhLuong();
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i)->TinhLuong() < min){
		   min = danhsach.LayGiaTri(i)->TinhLuong();
		}
	}
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i)->TinhLuong() == min){
		   danhsach.LayGiaTri(i)->Xuat();
		   cout<<"luong : "<<(size_t)danhsach.LayGiaTri(i)->TinhLuong();
		}
	}
}
//thuc hien chuc nang nang cao, sapxep theo luong

void SapXep(List <NhanVien *> &danhsach)
{
	for(int i = 0;i < danhsach.Size();i++)
	{
		for(int j = i+1;j < danhsach.Size();j++)
		{
			if(danhsach.LayGiaTri(i)->TinhLuong()>danhsach.LayGiaTri(j)->TinhLuong()){
				NhanVien *nv = danhsach.LayGiaTri(i);
				danhsach.SetGiaTri(i,danhsach.LayGiaTri(j));
				danhsach.SetGiaTri(j,nv);
			}
     	}
   }
}

void DanhSachSort(List <NhanVien *> danhsach)
{
	for(int i = 0;i < danhsach.Size();i++)
	{
		cout<<"\nnhan vien thu "<<i+1<<"\n";
		danhsach.LayGiaTri(i)->Xuat();
		cout<<"luong : "<<(size_t)danhsach.LayGiaTri(i)->TinhLuong();
		cout<<"\n";
	}
}

void XuatDanhSach(List <NhanVien *> &danhsach)
{
	cout << "\n--------Danh sanh nhan vien quan ly--------\n" << endl;
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i) ->LayLoai() == 1){
			danhsach.LayGiaTri(i) ->Xuat();
			cout<<"luong : "<<(size_t)danhsach.LayGiaTri(i) ->TinhLuong() ;
		 	cout<<"\n";
		}
	}
	cout << "\n--------Danh sanh nhan vien lap trinh--------\n" << endl;
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i)->LayLoai() == 2){
			danhsach.LayGiaTri(i)->Xuat();
			cout<<"luong : "<<(size_t)danhsach.LayGiaTri(i) ->TinhLuong();
		 	cout<<"\n";
		}
	}
	cout << "\n--------Danh sanh nhan vien van phong--------\n" << endl;
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i)->LayLoai() == 3){
			danhsach.LayGiaTri(i)->Xuat();
			cout<<"luong : "<<(size_t)danhsach.LayGiaTri(i)->TinhLuong() ;
		 	cout<<"\n";
		}
	}
}

void TinhTongLuong(List <NhanVien *> &danhsach)
{
	float tongluong1 = 0;
	float tongluong2 = 0;
	float tongluong3 = 0;	
	for(int i = 0;i < danhsach.Size();i++)
	{ 
	    if(danhsach.LayGiaTri(i)->LayLoai() == 1){
	       tongluong1 = tongluong1 + danhsach.LayGiaTri(i) ->TinhLuong();
		}
		else if (danhsach.LayGiaTri(i) ->LayLoai() == 2){
		   tongluong2 = tongluong2 + danhsach.LayGiaTri(i) ->TinhLuong() ;
		}
		else if(danhsach.LayGiaTri(i) ->LayLoai() == 3){
		   tongluong3 = tongluong3 + danhsach.LayGiaTri(i) ->TinhLuong() ;
		}
	}
	float tong = tongluong1 + tongluong2 + tongluong3;
    cout << "tong luong quan ly : " << (size_t)tongluong1 << endl;
    cout << "tong luong lap trinh vien : "<<(size_t)tongluong2 << endl;
    cout << "tong luong van phong : "<< (size_t)tongluong3 << endl;
    cout << "tong luong toan bo nhan vien: "<< (size_t)tong << endl;
}

void LuuFile(List <NhanVien *> &danhsach)
{
	for(int i = 0;i < danhsach.Size();i++)
	{
		if(danhsach.LayGiaTri(i) ->LayLoai()==1){
		    ofstream fileluu1("employee.txt",ios::app);
		    fileluu1<<danhsach.LayGiaTri(i) ->LayMa();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayTen();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayNgaySinh();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayEmail();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayDienThoai();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayDiaChi();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayChucVu();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayHeSoCV();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayThuong();
		    fileluu1<<",";
		    fileluu1<<(size_t)danhsach.LayGiaTri(i) ->LayLuongCoBan();
		    fileluu1<<"\n";
		    fileluu1.close();
		}
		else if(danhsach.LayGiaTri(i) ->LayLoai()==2){
		    ofstream fileluu1("employee.txt ",ios::app);
		    fileluu1<<danhsach.LayGiaTri(i) ->LayMa();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayTen();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayNgaySinh();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayEmail();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayDienThoai();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i)->LayDiaChi();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayTLamViec();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayTNgoaiGio();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayTroCap();
		    fileluu1<<",";
		    fileluu1<<(size_t)danhsach.LayGiaTri(i) ->LayLuongCoBan();
		    fileluu1<<"\n";
		    fileluu1.close();
		}
		else{
			ofstream fileluu1("employee.txt",ios::app);
			fileluu1<<danhsach.LayGiaTri(i) ->LayMa();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayTen();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayNgaySinh();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayEmail();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayDienThoai();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayDiaChi();
			fileluu1<<",";
			fileluu1<<danhsach.LayGiaTri(i) ->LayTroCap();
			fileluu1<<",";
		    fileluu1<<(size_t)danhsach.LayGiaTri(i) ->LayLuongCoBan();
		    fileluu1<<"\n";
		    fileluu1.close();
		}  
	}
}

void DocFile(List <NhanVien *> &danhsach)
{  
	ifstream fileluu1("employee.txt");
    try{
     		cout<<"mo thanh cong\n";
	     	while(!fileluu1.eof())
			{
				int ma;
			    string ten;
			    string ngay_sinh;
				string email;
				long int dien_thoai;
				string dia_chi;
				string chuc_vu;
			    float he_so_cv;
			    float thuong;
			    int t_lam_viec;
				int t_ngoai_gio;
				float tro_cap;
				string h;
				int kt = 0;
				getline(fileluu1,h,'\n');
				int k = 0;
				for(int i = 0;i < h.length();i++)
				{
					if(h[i] == ','){
						k = k+1;
					}
				}
				char c[h.size()];
				copy(h.begin(),h.end(),c);
				if(k != 0){
					char *s;
					s = strtok(c,",");
					ma = atoi(s);
					if (!atof(s)){
					    kt = 1;
				    }
					NgoaiLeSo1(ma,kt);
					ten = strtok(NULL,",");
					if(ten.length()<=6){
						kt = 1;
				    }	
					ngay_sinh = strtok(NULL,",");
					email = strtok(NULL,",");
					size_t t = email.find("@");
					if(t == string::npos){
						kt = 1;	   	
					}
					s = strtok(NULL,",");
					dien_thoai = atoi(s);
					if(!atof(s)){
						kt = 1;
					}
					string S = to_string(dien_thoai);
				    NgoaiLeDT1(S.length(),kt);
					dia_chi = strtok(NULL,",");
					s = strtok(NULL,",");
					if (k == 9){
						if (atof(s)||s == "0"){
							t_lam_viec = atoi(s);
							NgoaiLeSo1(t_lam_viec,kt);
							s = strtok(NULL,",");
							t_ngoai_gio=atoi(s);
							if(!atof(s)){
							   	kt = 1;
							}
						    NgoaiLeSo1(t_ngoai_gio,kt);
							s = strtok(NULL,"\n");
							tro_cap = atof(s);
							if(!atof(s)){
							   	 kt = 1;
							}
							NgoaiLeSo1(tro_cap,kt);
							KiemTraNgay1(ngay_sinh,kt);
							NhanVien *nv = new LapTrinhVien;
							nv->SetMa(ma);
							nv->SetTen(ten);
							nv->SetNgaySinh(ngay_sinh);
							nv->SetEmail(email);
							nv->SetDienThoai(dien_thoai);
							nv->SetDiaChi(dia_chi);
							nv->SetTLamViec(t_lam_viec);
							nv->SetTNgoaiGio(t_ngoai_gio);
							nv->SetTroCap(tro_cap);	 
							if(kt == 0){
								danhsach.Add(nv);
							}
							
						}
						else{
							chuc_vu = s;
							s = strtok(NULL,",");
							he_so_cv = atof(s);
							if(!atof(s)){
								 kt = 1; 	 
							}
						   	NgoaiLeSo1(he_so_cv,kt);
							s = strtok(NULL,"\n");
							thuong = atof(s);
							if(!atof(s)){
								 kt = 1;
							}
						   	NgoaiLeSo1(thuong,kt);
						   	KiemTraNgay1(ngay_sinh,kt);
							NhanVien *nv=new QuanLy;
							nv->SetMa(ma);
							nv->SetTen(ten);
							nv->SetNgaySinh(ngay_sinh);
							nv->SetEmail(email);
							nv->SetDienThoai(dien_thoai);
							nv->SetDiaChi(dia_chi);
							nv->SetChucVu(chuc_vu);
							nv->SetHeSoCV(he_so_cv);
							nv->SetThuong(thuong);
							if(kt == 0){
								danhsach.Add(nv);
							}
						}
					}
					else if(k == 7){
						tro_cap=atof(s);
						if(!atof(s)){
							 kt = 1;
						}
						NgoaiLeSo1(tro_cap,kt);
						KiemTraNgay1(ngay_sinh,kt);
						NhanVien *nv = new VanPhong;
						nv->SetMa(ma);
						nv->SetTen(ten);
						nv->SetNgaySinh(ngay_sinh);
						nv->SetEmail(email);
						nv->SetDienThoai(dien_thoai);
						nv->SetDiaChi(dia_chi);
						nv->SetTroCap(tro_cap);
						if(kt == 0){
							danhsach.Add(nv);
						}
					} 
				}
				
				if(fileluu1.eof()){
		    		break;
				}
		   }
		   fileluu1.close();
	}catch(ifstream::failure e){
	 	cout<<"Exception opening/reading/closing file\n";
	}
}

void MenuInput(List <NhanVien *> &danhsach) {
	int check;
	do {
		system("cls");
		cout << "\n 1-Nhap thong tin manager.";
		cout << "\n 2-Nhap thong tin programmer.";
		cout << "\n 3-Nhap thong tin officer.";
		cout << "\n 0-Thoat.";
		cout << "\n Lua chon cua ban la: ";
		cin >> check;
		system("cls");
		switch (check) {
			case 1: {
				cout << "\n Ban nhap thong tin manager:\n";
                NhanVien *nv = new QuanLy;
                nv->Nhap();
                danhsach.Add(nv);
                system("pause");
				break;
			}
			case 2: {
				cout << "\n Ban nhap thong tin programmer:\n";
			    NhanVien *nv = new LapTrinhVien;
			    nv->Nhap();
			    danhsach.Add(nv);
				system("pause");
				break;
			}
			case 3: {
				cout << "\n Ban nhap thong tin officer:\n";
				NhanVien *nv = new VanPhong;
				nv->Nhap();
				danhsach.Add(nv);
			    system("pause");
				break;
			}
			case 0: {
				system("pause");
				break;
			}
		}
	} while (check != 0);
}

void Menu() {
	List <NhanVien *>danhsach;
	int chon;
	do {
		system("cls");
		cout << "\n ========Chuong Trinh Quan Ly Nhan Vien========";
		cout << "\n Moi Ban chon:";
		cout << "\n 1-Nhap thong tin nhan vien.";
		cout << "\n 2-Xem thong tin toan bo nhan vien.";
		cout << "\n 3-Xem thong tin tong luong nhan vien.";
		cout << "\n 4-luu thong tin ra file.";
		cout << "\n 5-sap xep tang dan theo luong.";
		cout << "\n 6-luong thap nhat va cao nhat.";
		cout << "\n 0-Thoat.";
		cout << "\n ============================================\n";
		cout << "\n Lua chon cua ban la: ";
		cin >> chon;
		system("cls");
		switch (chon) {
			case 1: {
			    MenuInput(danhsach);
			    system("pause");
				break;
			}
			case 2: {
				if(danhsach.Size() != 0){
					cout << "\n--------Danh sanh nhan vien chua luu vao file: --------\n" << endl;
			        XuatDanhSach(danhsach);
				}
			    List <NhanVien *>danhsachdl;
			    DocFile(danhsachdl);
			    if(danhsachdl.Size()){
			    	cout << "\n--------Danh sanh nhan vien da luu vao file: --------\n" << endl;
			    	XuatDanhSach(danhsachdl);
				}
				cout << "\n-----------------------------------\n" << endl;
				system("pause");
				break;
			}
			case 3: {
				if(danhsach.Size() != 0){
					cout << "\n--------tong luong nhung nhan vien chua luu vao file: --------\n" << endl;
				    TinhTongLuong(danhsach);
				}
				
				List <NhanVien *>danhsachdl;
				DocFile(danhsachdl);
				if(danhsachdl.Size() != 0){
					cout << "\n--------tong luong nhung nhan vien da luu vao file: --------\n" << endl;
					TinhTongLuong(danhsachdl);
				}	
                system("pause");
				break;
			}
			case 4: {
				cout << "\n-----------------------------------\n" << endl;
				LuuFile(danhsach);
				cout<<"\n thong tin da luu!\n";
				system("pause");
				break;
			}
			case 5: {
				cout << "\n--------Danh sanh nhan vien sap xep tang dan theo luong--------\n" << endl;
				List <NhanVien *>danhsachdl;
				DocFile(danhsachdl);
				if(danhsachdl.Size() != 0){
					cout<<"\ndanh sach da luu\n";
					SapXep(danhsachdl);
				    DanhSachSort(danhsachdl);
				}
				if(danhsach.Size() != 0){
					cout<<"\ndanh sach chua luu\n";
					SapXep(danhsach);
					DanhSachSort(danhsach);
				}
				cout << "\n-----------------------------------\n" << endl;
				system("pause");
				break;
			}
			case 6:{
				List <NhanVien *>danhsachdl;
				DocFile(danhsachdl);
				if(danhsachdl.Size() != 0){
					cout << "\n--------nhan vien co luong thap nhat trong danh sach da luu:--------\n" << endl;
					TimLuongMin(danhsachdl);
					cout << "\n--------nhan vien co luong cao nhat trong danh sach da luu:--------\n" << endl;
					TimLuongMax(danhsachdl);
				}
				if(danhsach.Size() != 0){
					cout << "\n--------nhan vien co luong cao nhat trong danh sach chua luu:--------\n" << endl;
					TimLuongMax(danhsach);
					cout << "\n--------nhan vien co luong thap nhat trong danh sach chua luu:--------\n" << endl;
					TimLuongMin(danhsach);
				}
				cout<<endl;
				system("pause");
				break;
			}
			case 0: {
				cout << "\n Cam on ban da su dung chuong trinh!";
				exit(0);
				system("pause");
				break;
			}	 
		}
	} while (chon != 0);
}

int main(int argc, char** argv) {
    Menu();
	return 0;
}

