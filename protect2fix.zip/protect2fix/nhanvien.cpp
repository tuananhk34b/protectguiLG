#include "nhanvien.h"
#include <iomanip>
#include <string.h>
//ham kiem tra ngay nhap co dung khong
void KiemTraNgay(string ngay,int &k)
{
	int j = 0;
	for(int i = 0;i < ngay.length();i++)
	{
		if(ngay[i] == '/'){
			j = j+1;
		}
	}
	if(j != 2){
		k=1;
	}
	else{
		char h[ngay.size()];
		copy(ngay.begin(),ngay.end()+1,h);
		int date = atoi(strtok(h,"/"));
		int thang = atoi(strtok(NULL,"/"));
		int nam = atoi(strtok(NULL,"\n"));
		if(nam <= 1950){
			k = 2;
		}
		else if(thang < 1||thang > 12){
			k = 3;
		}
		else if(date < 0||date > 31){
			k = 4;
		}
		else if((date > 28&&thang == 2)){
			k = 5;
		}
		else if((date > 30)&&(thang == 4||thang == 6||thang == 9||thang == 11)){
			k = 5;
		}
		else{
			k = 0;
		}
	}	
}
//cac ham xu ly ngoai le
void NgoaiLeSo(int so)
{
	try{
		if(so < 0)
		  throw so;
	}
	catch(int so){
	    cout << "du lieu so khong the nho hon 0,nhap lai : "; 
	}
}

void NgoaiLeChuoi(string h)
{
	try{
		if(h.length() < 6)
		  throw h;
	}
	catch(string h){
	    cout<<"chuoi phai co it nhat 6 ky tu,nhap lai : "; 
	}
}

void NgoaiLeNgay(int k){
	try{
		if(k == 1)
		  throw k;
		else if(k == 2)
		  throw k;
		else if(k == 3)
		  throw k;
		else if(k == 4||k == 5)
		  throw k;
	}
	catch(int k){
	    if(k == 1){
	    	cout << "du lieu phai co dang dd/mm/yyyy,nhap lai: ";
		}    
		else if(k == 2){
			cout<<"nam phai lon 1950, nhap lai: ";
     	}
		else if(k == 3){
			cout << "thang phai tu 1 den 12,nhap lai: ";
		}		
		else if(k == 4||k == 5){
			cout << "ngay phai lon hon 0 va nho hon so ngay toi da cua thang, nhap lai: ";
		}	
	}
}

void NgoaiLeDT(int t)
{
	try{
		if(t != 9)
		  throw t;
	}
	catch(int t){
	    cout << "so dt phai co 10 so va bat dau = 0, nhap lai: "; 
	}
}

NhanVien::NhanVien()
{
	luong_co_ban = 2500000;
}

NhanVien::~NhanVien()
{
}

long int NhanVien::LayLuongCoBan(){};
int NhanVien::LayMa(){};
string NhanVien::LayTen(){};
string NhanVien::LayEmail(){};
long int NhanVien::LayDienThoai(){};
string NhanVien::LayDiaChi(){}; 
string NhanVien::LayNgaySinh(){};
void NhanVien::SetMa(int ma1){};
void NhanVien::SetTen(string ten1){};
void NhanVien::SetEmail(string mail){};
void NhanVien::SetNgaySinh(string ngaysinh1){};
void NhanVien::SetDienThoai(long int dt){};
void NhanVien::SetDiaChi(string dc){}; 
string NhanVien::LayChucVu(){};
float NhanVien::LayHeSoCV(){};
float NhanVien::LayThuong(){};
int NhanVien::LayTLamViec(){};
int NhanVien::LayTNgoaiGio(){};
float NhanVien::LayTroCap(){};
void NhanVien::SetChucVu(string cv){};
void NhanVien::SetHeSoCV(float heso){};
void NhanVien::SetThuong(float thuong1){};
void NhanVien::SetTLamViec(int t){};	 
void NhanVien::SetTNgoaiGio(int t){};	 
void NhanVien::SetTroCap(int tc){}; 
int NhanVien::LayLoai(){};

void NhanVien::Nhap()
{
	cout << "ma: ";
	cin >> ma;
	while(cin.fail()||ma <= 0){
		if (cin.fail()){
		   	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout << "du lieu sai,nhap lai: ";
		   	cin >> ma;	
		}
		else if(ma <= 0){
		   	NgoaiLeSo(ma);
		   	cin >> ma;
		}
	}
	cin.ignore();
	cout<<"nhap ten: ";
	getline(cin,ten);
	while(ten.length() <= 6){
		NgoaiLeChuoi(ten);
		getline(cin,ten);
    }
	cout<<"ngay sinh: ";
	getline(cin,ngay_sinh);
	int k = 0;
	KiemTraNgay(ngay_sinh,k);
	while(k!=0){
		NgoaiLeNgay(k);
		getline(cin,ngay_sinh);
		KiemTraNgay(ngay_sinh,k);
	}
	cout << "email: ";
	getline(cin,email);	
	while(true){
		size_t t = email.find("@");
		if(t == string::npos){
		   	cout << "email phai co @,nhap lai : ";
		   	getline(cin,email);
		}
		else{
		   	break;
		}
	}
    cout << "so dien thoai: ";
    cin >> dien_thoai;
	while(cin.fail()){
		cin.clear();
		cin.ignore(1000,'\n');
		cout << "du lieu sai,nhap lai: ";
		cin >> dien_thoai;
	}
	string s = to_string(dien_thoai);
	while(s.length() != 9)
	{
	    NgoaiLeDT(s.length());
		cin >> dien_thoai;
		s = to_string(dien_thoai);
	}
	cin.ignore();
	cout << "dia chi: ";
	getline(cin,dia_chi);
}

void NhanVien::Xuat()
{
	cout << "\n----thong tin chung----- :\n";
	cout << "ma: "<< ma <<"\n";
	cout << "ten: "<< ten <<"\n";
	cout << "ngay sinh: "<< ngay_sinh << "\n";
	cout << "email: "<< email << "\n";
	cout << "so dien thoai: "<< 0 << dien_thoai << "\n";
	cout << "dia chi: " << dia_chi << "\n";
}

float NhanVien::TinhLuong(){}
