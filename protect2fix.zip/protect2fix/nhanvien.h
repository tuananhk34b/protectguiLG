#include <iostream>
#include <string>
#pragma once
using namespace std;

class NhanVien
{
	protected:
		int ma;
    	string ten;
    	string ngay_sinh;
    	string email;
    	long int dien_thoai;
    	string dia_chi;
    	long int luong_co_ban;
	public:
		NhanVien();
		~NhanVien();
     	virtual long int LayLuongCoBan();
		virtual int LayMa();
		virtual string LayTen();
		virtual string LayEmail();
		virtual long int LayDienThoai();
		virtual string LayDiaChi(); 
		virtual string LayNgaySinh();
		virtual void SetMa(int ma1);
		virtual void SetTen(string);
		virtual void SetEmail(string);
		virtual void SetNgaySinh(string);
		virtual void SetDienThoai(long int);
		virtual void SetDiaChi(string); 
		virtual string LayChucVu();
		virtual float LayHeSoCV();
		virtual float LayThuong();
		virtual int LayTLamViec();
		virtual int LayTNgoaiGio();
		virtual float LayTroCap();
		virtual void SetChucVu(string);
		virtual void SetHeSoCV(float);
		virtual void SetThuong(float);
		virtual void SetTLamViec(int);	 
		virtual void SetTNgoaiGio(int);	 
		virtual void SetTroCap(int); 
		virtual int LayLoai();
		virtual void Nhap();
		virtual void Xuat();
		virtual float TinhLuong();
};
