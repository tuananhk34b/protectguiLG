#include "nhanvienvp.h"
long int VanPhong::LayLuongCoBan()
{
	return luong_co_ban;
}

int VanPhong::LayMa()
{
	return ma;
}

string VanPhong::LayTen()
{
    return ten;
}

string  VanPhong::LayEmail()
{
	return email;
}

long int VanPhong ::LayDienThoai()
{
    return dien_thoai;
}

string  VanPhong::LayDiaChi()
{
	return dia_chi;
}

string  VanPhong::LayNgaySinh()
{
	return ngay_sinh;
}

void  VanPhong::SetMa(int ma1)
{
	ma =  ma1;
}

void  VanPhong::SetTen(string ten1)
{
	ten = ten1;
}

void  VanPhong::SetEmail(string mail)
{
	email = mail;
}

void  VanPhong::SetNgaySinh(string ngay_sinh1)
{
	ngay_sinh = ngay_sinh1;
}

void  VanPhong::SetDienThoai(long int dt)
{
	dien_thoai = dt;
}

void  VanPhong::SetDiaChi(string dc)
{
	dia_chi = dc;
}

void  VanPhong::SetTroCap(int tc)
{
	tro_cap=tc;
}

float VanPhong ::LayTroCap()
{
	return tro_cap;
}

VanPhong:: VanPhong()
{
	loai = 3;
}

int VanPhong ::LayLoai()
{
	return loai;
}

//ham xu ly ngoai le
void NgoaiLe3(int so)
{
	try{
		if(so<0)
		  throw so;
	}
	catch(int so){
	    cout<<"du lieu so khong the nho hon 0,nhap lai : "; 
	}
}

void VanPhong::Nhap()
{	
	NhanVien::Nhap();
	cout << "nhap tro cap: ";
	cin >> tro_cap;
	while(cin.fail()){
	   	cin.clear();
	   	cin.ignore(1000,'\n');
	   	cout << "du lieu sai,nhap lai: ";
	   	cin >> tro_cap;
	}
	while(tro_cap < 0){
		NgoaiLe3(tro_cap);
		cin >> tro_cap;
	}
}

void VanPhong ::Xuat()
{
	NhanVien::Xuat();
	cout << "-----thong tin rieng------\n";
	cout << "tro cap: "<< (size_t)tro_cap << "\n";
}

float  VanPhong::TinhLuong()
{
	float luong;
	luong = luong_co_ban + tro_cap;
	return luong;
}
