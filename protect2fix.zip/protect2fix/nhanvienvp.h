#include "nhanvien.h"
#pragma once
class VanPhong: public NhanVien
{
	protected:
		float tro_cap;
		int loai;
	public:
		long int LayLuongCoBan();
		int LayMa();
		string LayTen();
		string LayEmail();
		long int LayDienThoai();
		string LayDiaChi();
		string LayNgaySinh();
		void SetMa(int);
	    void SetTen(string);
		void SetEmail(string);
		void SetNgaySinh(string);
	    void SetDienThoai(long int);
	    void SetDiaChi(string);
		void SetTroCap(int);
		float LayTroCap();
		VanPhong();
		int LayLoai();
		void Nhap();
		void Xuat();
		float TinhLuong();
};
