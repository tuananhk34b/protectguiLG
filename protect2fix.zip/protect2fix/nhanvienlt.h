#include "nhanvien.h"
#pragma once
class LapTrinhVien :public NhanVien
{
	protected:
		int t_lam_viec;
		int t_ngoai_gio;
		float tro_cap;
		int loai;
	public:
		long int LayLuongCoBan(); 
		int LayMa(); 
		string LayTen();
		string LayEmail();	 
		long int LayDienThoai();
		string LayDiaChi();
		string LayNgaySinh();	 
		void SetMa(int);	 
	    void SetTen(string);
		void SetEmail(string);
		void SetNgaySinh(string);
	    void SetDienThoai(long int);
	    void SetDiaChi(string);	 
		void SetTLamViec(int);	 
		void SetTNgoaiGio(int);
		void SetTroCap(int);	 
		int LayTLamViec();
	    int LayTNgoaiGio();
		float LayTroCap();
		LapTrinhVien();
		int LayLoai();
		void Nhap();
		void Xuat();
		float TinhLuong();
};
