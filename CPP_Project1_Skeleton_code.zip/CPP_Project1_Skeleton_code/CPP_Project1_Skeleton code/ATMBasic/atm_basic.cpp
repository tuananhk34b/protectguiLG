#include <iostream>
#include <string>
using namespace std;
/* day la ung ung viet tren ide dev c++ phien ban 5.11*/
string account_number;
int menu_option;
int withdraw_option;
float deposit_amount;
char welcome_option;
float balance_amount = 5000000;

// Function declarations
void Welcome();
void ShowMenu();
void CheckBalance();
void Withdraw();
void Deposit();
void Eject();
void NhapThongTinKhachHang();
int main()
{
	cout << "--ATM C++ kinh chao quy khach--" << endl;
	cout << "--Vui long dua the ATM vao--" << endl;
	system("pause");
	Welcome();
	//your code here
	system("pause");
	return 0;
}

// Hien thi thong diep welcome va
// yeu cau nguoi dung nhap vao tai khoan giao dich
void Welcome() {
	system("cls");
	/*nhap so tai khoan*/
	cout << "--ATM C++ kinh chao quy khach--" << endl;
	cout << "Da nhan duoc the, vui long nhap tai khoan giao dich:" << endl;
	cin >> account_number;
	cout<<"tai khoan :"<<account_number<<endl;
	//your code here
	/*hoi khach muon nhap lai ko ? */
    cout<<"ban co muon nhap lai tai khoan khong (y/n)";
	cin >> welcome_option;
	system("cls");
     while (true) {
     	/*khach chi co the nhap y hoac n .neu khach nhap sai ,chuong trinh se chay vong lap ,buoc nhap lai
		 vong lap chi dung neu khach nhap y hoac n*/
		if (welcome_option != 'n' && welcome_option != 'y'){
			//your code here
			cout<<"vui long chi nhap 'y' hoac 'n' \n";
			cout<<"ban co muon nhap lai tai khoan khong (y/n)";
			cin >> welcome_option;
			continue;
		}
		//neu khacch nhap y .chuong trinh se hien ra ,cho khach nhap lai theo yeu cau
		if (welcome_option == 'y') {
			cout<<"so tai khoan da nhap :"<<account_number<<endl;
			cout<<"vui long nhap lai :\n";
			cout<<"tai khoan: ";
			cin>>account_number;
			break;
			//break la lenh dung vong lap.neu khach nhap dung 
			//your code here
		} else {
			break;
			//your code here
		}
	}
	system("pause");
	ShowMenu();
}

// Hien thi menu voi 4 chuc nang
void ShowMenu() {
	do {
		/*day la menu hien thi theo yeu cau*/
		system("cls");
		cout<<"\nmenu: ";
		cout<<"\n 1.tra cuu so du: ";
		cout<<"\n 2.rut tien: ";
		cout<<"\n 3.nap tien: ";
		//bo sung tinh nang moi theo yeu cau nang cao cua de bai :
		cout<<"\n 4.cap nhap thong tin ";
		cout<<"\n 5.ngung giao dich: ";
		cout<<"\nvui long chon menu (tu 1 den 4):";
		//your code here
		cin >> menu_option;
	} while (menu_option < 1 || menu_option > 5);
   
	switch (menu_option) {
	case 1:
		CheckBalance();
		break;
	case 2:
		Withdraw();
		break;
	case 3:
		Deposit();
		break;
	case 4:
	    NhapThongTinKhachHang() ;
		break;
	case 5:
		Eject();
	}
}

// Tra cuu so du
void CheckBalance()
{
	system("cls");
	/*day la hien thi so du ,neu khach chon 1*/
	cout<<"tai khoan: "<<account_number<<endl;
	cout<<"so du: "<<(size_t)balance_amount<<endl;
	//your code here
	system("pause");
	ShowMenu();
}

// Rut tien trong tai khoan
void Withdraw()
{
	system("cls");
	do {
		cout << "--RUT TIEN--" << endl;
		//your code here
		/*day la meunu rut tien neu khach chon 2*/
		cout<<"\nvui long chon so tien de rut ";
		cout<<"\n1. 50000(nam muoi nghin dong)";
		cout<<"\n2. 100000(mot tram nghin dong)";
		cout<<"\n3. 200000(hai tram nghin dong)";
		cout<<"\n4. 500000(nam tram nghin dong)";
		cout<<"\n5. 1000000(mot trieu dong)";
		cout<<"\n6. 2000000(hai trieu dong)";
		//thuc hien yeu cau nang cao cua de bai :so tien rut la so khac ,la boi so 50000;
		cout<<"\n7. 2500000(hai trieu nam tram ngan dong)";
		cout<<"\n8. thoat ve man hinh chinh";
		cin >> withdraw_option;
		cout << endl;
	} while (withdraw_option < 1 || withdraw_option > 7);


	int withdraw_amount = 0; // So tien muon rut
	switch (withdraw_option) {
		/*chinh lai so tien muon rut theo yeu cau nhap cua khach*/
		case 1:
			withdraw_amount=50000;
			break;
			//your code here
		case 2:
			withdraw_amount=100000;
			break;
			//your code here
		case 3:
			withdraw_amount=200000;
			break;
			//your code here
		case 4:
			withdraw_amount=500000;
			break;
			//your code here
		case 5:
			withdraw_amount=1000000;
			break;
			//your code here
		case 6:
			withdraw_amount=2000000;
			break;
			//your code here
		case 7:
			withdraw_amount=2500000;
			break;
		case 8:
			cout << "\nVe man hinh chinh..." << endl;
			system("pause");
			ShowMenu();
			return;
	}
	/*(size_t) la lenh dung de hien thi balance_amount duoi dang 5000000 theo yeu cau nang cao cua de bai */
	if ((size_t)balance_amount > withdraw_amount) {
		//your code here
		cout<<"rut "<<(size_t)withdraw_amount<<" tu:";
		cout<<"\nso tai khoan: "<<account_number;
		//so tien du hien tai=so du cu - so tien rut
		balance_amount=balance_amount-withdraw_amount;
		cout<<"\nso du hien tai: "<<(size_t)balance_amount;
		cout<<"\nvui long nhan ATM va kiem tra tien truoc khi di"<<endl;
	} else {
		//your code here
        cout<<"\nso du nho hon "<<withdraw_amount<<", khong the thuc hien giao dich ";
        cout<<"\nso du hien tai: "<<(size_t)balance_amount;
		cout << "Vui long nhan lai the ATM va kiem tra tien truoc khi di" << endl;
	}
	system("pause");
	ShowMenu();
}


// Nap tien vao tai khoan
void Deposit()
{
	system("cls");
	cout << "Nap tien" << endl;	
	cin>>deposit_amount;
	// thuc hien yeu cau nang cao neu so tien nap vao ko hop le : la so am hoac ko phai so;
    while(cin.fail()||deposit_amount < 0){
    	if(cin.fail()){
	    	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"du lieu sai,nhap lai: ";
		   	cin>>deposit_amount;
		}
		else if(deposit_amount < 0){
			cout<<"so tien nap ko the la so am,nhap lai: ";
			cin>>deposit_amount;
		}	
	}
	//tinh so du hien tai;
	balance_amount=balance_amount+deposit_amount;
	//your code here
	/*(size_t) la lenh dung de hien thi balance_amount duoi dang 5000000 theo yeu cau nang cao cua de bai*/
	cout << "\nSo du hien tai: " << (size_t)balance_amount << endl;
	cout << endl;
	system("pause");
	ShowMenu();
}
//bo sung tinh nang moi theo yeu cau nang cao cua de bai;
void NhapThongTinKhachHang()
{
	cin.ignore();
	cout<<"\nnhap ten : ";
	string ten;
	cin>>ten;
	cout<<"\nnhap dia chi: ";
	string dia_chi;
	cin>>dia_chi;
	cout<<"\nnhap so can cuoc cong dan : ";
	long int cccd;
	cin>>cccd;
	cin.ignore();
	cout<<"\nnhap gioi tinh: ";
	string sex;
	cin>>sex;
	cout<<"\nthong tin sau nhap :\n";
	cout<<ten<<"\t"<<dia_chi<<"\t"<<cccd<<"\t"<<sex<<endl;
	system("pause");
	ShowMenu();
}
// Ngung giao dich
void Eject()
{
	system("cls");
	cout << "--ATM C++--" << endl;
	cout << "\nKet thuc..." << endl;
	cout << "\nVui long nhan the va tien o khe cam" << endl;
	cout << "\nCam on quy khach da su dung dich vu tai ATM C++" << endl;
}
