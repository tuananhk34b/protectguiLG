IDE :protect nay duoc viet tren dev C phien ban 5.11
cac tinh nang nang cao da cai dat: them chuc nang moi:nhap thong tin khach hang o ham NhapThongTinKhachHang()
                                   kiem tra so tien nhap co phai so khong
                                   them vao so tien rut la boi so 50000
                                   xuat ra so co dinh dang: xxx.xxx, dung ham size_t
                                   