#include <iostream>
#include "sach.h"
#include "phieu.h"
#include <list>
#include <algorithm>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//ham tach chuoi thanh ngay thang nam kieu int
void TachNgay(int &nam, int &thang, int &ngay,string n)
{
	char h[n.size()];
	copy(n.begin(),n.end(),h);
	ngay = atoi(strtok(h,"/"));
	thang = atoi(strtok(NULL,"/"));
	nam = atoi(strtok(NULL,"\n"));
}
//ham sap xep theo ngay
bool SapTheoNgay(Phieu p1,Phieu p2)
{
	int ngay1 = 0,ngay2 = 0;
	int thang1 = 0,thang2 = 0;
	int nam1 = 0,nam2 = 0;
	TachNgay(nam1,thang1,ngay1,p1.LayNgayMuon());
	TachNgay(nam2,thang2,ngay2,p2.LayNgayMuon());
	int n1 = ((nam1*100) + thang1)*100 + ngay1;
	int n2 = ((nam2*100) + thang2)*100 + ngay2;
    return (n1 < n2); 
}
//ham sap xep theo nam xuat ban
bool SapNXB(Sach b1,Sach b2)
{
	return(b1.LayNXB() < b2.LayNXB());
}
//ham tim kiem sach theo tieu de
void TimKiemSach(list <Sach> dssach)
{
	cout << "nhap tieu de sach can tim: ";
	string tieu_de;
	cin.ignore();
	getline(cin,tieu_de);
	Sach b(tieu_de);
	list <Sach>::iterator it;
	it = find(dssach.begin(),dssach.end(),b);
	if(it != dssach.end()){
		cout << "tim thay tieu de nay: \n";
		it->Xuat();
	}
	else{
		cout << "khong tim thay tieu de nay: \n";
	}
}
//ham xuat danh sach sach
void DanhSachSach(list <Sach> dssach)
{
    list<Sach> ::iterator i;
    for(i = dssach.begin();i != dssach.end();i++)
    {
    	i->Xuat();
	}
} 
//ham kiem tra xem sach muon muon co o trong thu vien khong
void Check(list <Sach> dssach,int ma,int &k,int &so_luong)
{
	list<Sach> ::iterator i;
    for(i = dssach.begin();i != dssach.end();i++)
    {
        if(i->LayMa() == ma){
        	k = 1;
        	cout << "sach can muon: \n";
        	cout << setw(10)<<"ma sach" << setw(18) <<" tieu de" << setw(8)<<"namxb" << setw(12);
        	cout << "NXB" << setw(12) << "tac gia" << setw(14) << "the loai" << setw(10) << "so luong" <<endl;
        	i->Xuat();
        	if(i->LaySoLuong() > 0)
        	{
        		so_luong = i->LaySoLuong();
			}
		}
	}
}
//ham giam so luong sach di 1 neu sach do duoc muon
void CapNhapSoLuongSach(list <Sach> &dssach,int ma)
{
	list<Sach> ::iterator i;
    for(i = dssach.begin();i != dssach.end();i++)
    {
        if(i->LayMa() == ma){
           i->SetSoLuong(i->LaySoLuong() - 1);
		}
	}
}
//ham tang so luong sach neu sach do duoc tra lai
void TangSoLuongSach(list <Sach> &dssach,int ma)
{
	list<Sach> ::iterator i;
    for(i = dssach.begin();i != dssach.end();i++)
    {
        if(i->LayMa() == ma){
           i->SetSoLuong(i->LaySoLuong() + 1);
		}
	}
}
//xuat phieu dang muon va phieu da tra
void DSPhieuMuon(list <Phieu> dsphieu)
{
	list<Phieu> ::iterator i;
	cout << "danh sach phieu dang muon: \n";
	cout << setw(13) << "ma phieu muon" << setw(15) << "ms nguoi muon" << setw(20) << "ten" << setw(12);
	cout << "ma sach" << setw(15) << "ngay muon";
	cout << setw(16) << "tt sach muon" << setw(14) << "tinh trang" << endl;
    for(i = dsphieu.begin();i != dsphieu.end();i++)
    {   
	    if(i->LayTrangThai() == true){
		    i->XuatPMuon();
		}    
	}
	cout <<"danh sach phieu da tra: \n";
	cout << setw(13) <<"ma phieu muon" << setw(13) << "ms nguoi muon" << setw(15) << "ten";
	cout << setw(9) << "ma sach" << setw(10) << "ngay muon"<< setw(10) << "ngay tra";
	cout << setw(13) << "tt sach muon" << setw(13) << "tt sach tra" << setw(12) << "tinh trang" << endl;
	for(i = dsphieu.begin();i != dsphieu.end();i++)
    {   
	    if(i->LayTrangThai() == false){
		    i->XuatPTra();
	    }
	}	
}
/*ham kiem tra xem ma phieu can muon co o trong danh sach phieu dang muon khong?.neu phieu nay 
da co trong danh sach dang muon se khong the duoc tao,dam bao ma phieu dang muon luon la duy nhat*/
void TimMaPhieu(list <Phieu> dsphieu,int ma,int &k)
{
	list<Phieu> ::iterator i;
    for(i = dsphieu.begin();i != dsphieu.end();i++)
    {
    	if(i->LayMaPhieuMuon() == ma){
    		cout << "phieu dang muon can tra :\n";
    		cout << setw(13) << "ma phieu muon"<< setw(15) << "ms nguoi muon" << setw(20) << "ten";
			cout << setw(12) << "ma sach"<< setw(15) << "ngay muon";
    		cout << setw(16) << "tt sach muon" << setw(14) << "tinh trang" << endl;
    		i->XuatPMuon();
    		k = 1;
		}   
	}
}
/*ham tim ma phieu can tra ,roi sau do tim ma sach theo ma phieu , neu sach nay co trong thu vien 
thi se tang so luong sach nay len 1*/
void TimMaPhieu1(list <Phieu> dsphieu,int ma,int &k,int &ms)
{
	list<Phieu> ::iterator i;
    for(i = dsphieu.begin();i != dsphieu.end();i++)
    {
    	if(i->LayMaPhieuMuon() == ma){
    		cout << "phieu dang muon can tra :\n";
    		cout << setw(13) << "ma phieu muon" << setw(15) << "ms nguoi muon"<< setw(20) << "ten";
			cout << setw(15) << "ngay muon"<< setw(12) << "ma sach";
			cout << setw(16) << "tt sach muon" << setw(14) << "tinh trang" << endl;
    		i->XuatPMuon();
    		ms = i->LayMa();
    		k = 1;
		}   
	}
}
//nhap phieu tra
void NhapPhieuTra(list <Phieu> &dsphieu,list <Sach> &dssach)
{
	cout<<" ma phieu muon can tra : ";
	int ma;
	cin >> ma;
	int k = 0;
	int ma_sach = 0;
	TimMaPhieu1(dsphieu,ma,k,ma_sach);
	if(k == 1){
		TangSoLuongSach(dssach,ma_sach);
		cout <<"ngay tra: ";
		string ngay;
		cin.ignore();
		getline(cin,ngay);
		cout << "tinh trang sach tra(cu/binh thuong/moi): ";
		string t;
		getline(cin,t);
		while(t != "cu"&&t != "binh thuong"&&t != "moi"){
			cout<<"du lieu ko hop le, nhap lai: ";
			getline(cin,t);
		}
		list<Phieu> ::iterator i;
	    for(i = dsphieu.begin();i != dsphieu.end();i++)
	    {
	         if(i->LayMaPhieuMuon() == ma)
	         {
	         	 i->SetNgayTra(ngay);
	         	 i->SetTinhTrangSachTra(t);
	         	 i->SetTrangThai(false);
			 }
		}
	}
}

void Menu() {
	list <Sach> dssach;
	list <Phieu> dsphieu;
	int ck;
	do {
		cout << "\n ========Chuong Trinh Quan Ly Thu Vien========";
		cout << "\n Moi Ban chon:";
		cout << "\n 1-Nhap thong tin sach.";
		cout << "\n 2-Danh sach thong tin sach.";
		cout << "\n 3-Muon sach.";
		cout << "\n 4-Tra sach.";
		cout << "\n 5-Danh sach phieu muon.";
		cout << "\n 6-tim kiem theo tieu de sach.";
		cout << "\n 7-sap xep sach theo nam xuat ban.";
		cout << "\n 0-Thoat.";
		cout << "\n ============================================\n";
		cout << "\n Lua chon cua ban la: ";
		cin >> ck;
		system("cls");
	switch (ck) {
		case 1: {
			Sach b;
			b.Nhap();
			dssach.push_back(b);
		}
		system("pause");
		break;
		case 2: {
			cout<<setw(10)<<"ma sach"<<setw(18)<<"tieu de"<<setw(8)<<"namxb"<<setw(12)<<"NXB";
			cout<<setw(12)<<"tac gia"<<setw(14)<<"the loai"<<setw(10)<<"so luong"<<endl;
			DanhSachSach(dssach);
		}
		system("pause");
		break;
		case 3: {
			cout<<"nhap ma sach muon muon : ";
			int ma;
			cin >> ma;
			int k = 0;
			int so_luong = 0;
			Check(dssach,ma,k,so_luong);
			if(k == 1&&so_luong > 0){
				Phieu p;
				p.NhapP();
				int k1 = 0;
				TimMaPhieu(dsphieu,p.LayMaPhieuMuon(),k1);
				if(k1 == 0){
					p.SetMaSach(ma);
					dsphieu.push_back(p);
					CapNhapSoLuongSach(dssach,ma);
				}
			    else if(k1 == 1){
			    	cout<<"ma phieu nay da ton tai trong danh sach phieu dang muon \n";
				}
				
			}
			else if(k == 0){
				cout<<"ma sach  muon muon ko co";
			}
			else if(so_luong == 0){
				cout<<"sach nay da het trong thu vien";
			}
		}
		system("pause");
		break;
		case 4: {
			NhapPhieuTra(dsphieu,dssach);
		}
		system("pause");
		break;
		case 5: {
			dsphieu.sort(SapTheoNgay);
			DSPhieuMuon(dsphieu);
		}
		system("pause");
		break;
		case 6:{
			//chuc nang nang cao ,tim sach theo tieu de
			 TimKiemSach(dssach);
		}
		system("pause");
		break;
		case 7:{
			// sap xep theo nam xuat ban
			dssach.sort(SapNXB);
			cout<<"danh sach sach sau khi sort: \n";
			cout<<setw(10)<<"ma sach"<<setw(18)<<"tieu de"<<setw(8)<<"namxb"<<setw(12)<<"NXB";
			cout<<setw(12)<<"tac gia"<<setw(14)<<"the loai"<<setw(10)<<"so luong"<<endl;
			DanhSachSach(dssach);
		}
		system("pause");
		break;
		case 0: {
			cout << "\n Cam on ban da su dung chuong trinh!";
			exit(0);
			break;
		} 
	}
	 
	} while (ck != 0);
}

int main(int argc, char** argv) {
	Menu();
	return 0;
}
