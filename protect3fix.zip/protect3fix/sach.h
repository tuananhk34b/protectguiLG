 #include <string>
#include <iostream>
#pragma once
#include <iomanip>
 using namespace std;
 class Sach
{
	private:
		string tieu_de_sach;
		int nam_xuat_ban;
		string nha_xuat_ban;
		string tac_gia;
		string the_loai;
		int so_luong;
	protected:
		int ma_sach;
	public:
		Sach();
		~Sach();
		Sach(string);
		int LayMa();
		int LayNXB();
		int LaySoLuong();
		void SetSoLuong(int);	 
		void Nhap(); 
		void Xuat();
		bool operator==(Sach);
};
