#include "phieu.h"
void KiemTraNgay(string ngay,int &k)
{
	int j = 0;
	for(int i=0;i<ngay.length();i++)
	{
		if(ngay[i] == '/'){
			j = j+1;
		}
	}
	if(j != 2){
		k = 1;
	}
	else{
		char h[ngay.size()];
		copy(ngay.begin(),ngay.end()+1,h);
		int date = atoi(strtok(h,"/"));
		int thang = atoi(strtok(NULL,"/"));
		int nam = atoi(strtok(NULL,"\n"));
		if(nam <= 2000){
			k = 2;
		}
		else if(thang < 1||thang > 12){
			k = 3;
		}
		else if(date < 0||date > 31){
			k = 4;
		}
		else if((date >28 && thang == 2)){
			k = 5;
		}
		else if((date > 30)&&(thang == 4||thang == 6||thang == 9||thang == 11)){
			k = 5;
		}
		else{
			k = 0;
		}
	}	
}
Phieu::Phieu()
{
	ma_phieu_muon = 0;
	ma_so_nguoi_muon = 0;
    ten = "";
	ngay_muon = "";
	ngay_tra = "";
	tinh_trang_sach_muon = "";
	tinh_trang_sach_tra = "";
    trang_thai = true ;
}
Phieu::~Phieu(){};
int Phieu::LayMaPhieuMuon()
{
	return ma_phieu_muon;
}

void Phieu::SetMaSach(int ma)
{
	ma_sach = ma;
}

void Phieu::SetNgayTra(string ngay)
{
	ngay_tra = ngay;
}

void Phieu::SetTinhTrangSachTra(string t)
{
	tinh_trang_sach_tra = t;
}

void Phieu::SetTrangThai(bool tt)
{
	trang_thai = tt;
}

bool Phieu::LayTrangThai()
{
	return trang_thai;
}

string Phieu::LayNgayMuon()
{
	return ngay_muon;
}

void  Phieu::NhapP()
{
	cout<<"ma phieu muon : ";
	cin>>ma_phieu_muon;
	while(cin.fail()||ma_phieu_muon <= 100000){
		if (cin.fail()){
		   	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"du lieu sai,nhap lai: ";
		   	cin>>ma_phieu_muon;	
		}
		else if(ma_phieu_muon <= 100000){
		   	cout<<"ma phai lon hon 0 va gom 6 chu so,nhap lai: ";
		   	cin>>ma_phieu_muon;
		}
	}
	cout << "ma so nguoi muon: ";
	cin >> ma_so_nguoi_muon;
	while(cin.fail()||ma_so_nguoi_muon <= 100000){
		if (cin.fail()){
		   	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"du lieu sai,nhap lai: ";
		   	cin>>ma_so_nguoi_muon;	
		}
		else if(ma_so_nguoi_muon <= 100000){
		   	cout << "ma phai lon hon 0 va gom 6 chu so,nhap lai: ";
		   	cin >> ma_so_nguoi_muon;
		}
	}
	cin.ignore();
	cout<<"ten: ";
	getline(cin,ten);
	cout<<"ngay muon: ";
	getline(cin,ngay_muon);
	int k = 0;
	KiemTraNgay(ngay_muon,k);
	while(k != 0){
		if(k == 1){
			cout<<"du lieu phai co dang dd/mm/yyyy,nhap lai: ";
			getline(cin,ngay_muon);
			KiemTraNgay(ngay_muon,k);
		}
		else if(k == 2){
			cout<<"nam phai lon 2000, nhap lai: ";
			getline(cin,ngay_muon);
			KiemTraNgay(ngay_muon,k);
		}
		else if(k == 3){
		    cout<<"thang phai tu 1 den 12,nhap lai: ";
		    getline(cin,ngay_muon);
		     KiemTraNgay(ngay_muon,k);
		}
		else if(k == 4||k == 5){
			cout<<"ngay phai lon hon 0 va nho hon so ngay toi da cua thang, nhap lai: ";
			getline(cin,ngay_muon);
		    KiemTraNgay(ngay_muon,k);
		}
	}
	cout<<"tinh trang sach muon(cu/binh thuong/moi): ";
	getline(cin,tinh_trang_sach_muon);
	while(tinh_trang_sach_muon != "cu"&&tinh_trang_sach_muon != "binh thuong"&&tinh_trang_sach_muon != "moi"){
		cout<<"du lieu ko hop le, nhap lai: ";
		getline(cin,tinh_trang_sach_muon);
	}
	trang_thai = true;
}

void Phieu::XuatPMuon()
{
	cout<<setw(13)<<ma_phieu_muon<<setw(15)<<ma_so_nguoi_muon<<setw(20)<<ten;
	cout<<setw(12)<<ma_sach<<setw(15)<<ngay_muon;
	cout<<setw(16)<<tinh_trang_sach_muon<<setw(14)<<"dang muon"<<endl;
}

void Phieu::XuatPTra()
{
	cout<<setw(13)<<ma_phieu_muon<<setw(13)<<ma_so_nguoi_muon<<setw(15)<<ten;
	cout<<setw(9)<<ma_sach<<setw(10)<<ngay_muon<<setw(10)<<ngay_tra;
	cout<<setw(13)<<tinh_trang_sach_muon<<setw(13)<<tinh_trang_sach_tra<<setw(12)<<"da tra"<<endl;
}	
 
