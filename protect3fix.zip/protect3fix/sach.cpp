#include "sach.h"
Sach::Sach()
{
	tieu_de_sach = "";
	nam_xuat_ban = 0;
	nha_xuat_ban = "";
	tac_gia = "";
	the_loai = "";
    so_luong = 0;
    ma_sach = 0;
}
Sach::~Sach(){};
Sach::Sach(string tieu_de)
{
	tieu_de_sach = tieu_de;
}

int Sach::LayMa()
{
	return ma_sach;
}

int Sach::LayNXB()
{
	return nam_xuat_ban;
}

int Sach::LaySoLuong()
{
	return so_luong;
}

void Sach::SetSoLuong(int sl)
{
	so_luong = sl;
}

void Sach::Nhap()
{
    cout<<"ma sach: ";
	cin>>ma_sach;
	while(cin.fail()||ma_sach <= 100000){
		if (cin.fail()){
		    cin.clear();
		    cin.ignore(1000,'\n');
		   	cout<<"du lieu sai,nhap lai: ";
		   	cin>>ma_sach;	
		}
		else if(ma_sach <= 100000){
		   	cout<<"ma phai lon hon 0 va gom 6 chu so,nhap lai: ";
		   	cin>>ma_sach;
		}
	}
	cin.ignore();
	cout<<"tieu de sach: ";
	getline(cin,tieu_de_sach);
	cout<<"nam xuat ban: ";
	cin>>nam_xuat_ban;
	while(cin.fail()||nam_xuat_ban <= 1900){
		if (cin.fail()){
		   	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"du lieu sai,nhap lai: ";
		   	cin>>nam_xuat_ban;	
		}
		else if(nam_xuat_ban <= 1900){
		   	cout<<"nam xuat ban phai lon hon 1900,nhap lai: ";
		   	cin>>nam_xuat_ban;
		}
	}
	cin.ignore();
	cout<<"nha xuat ban: ";
	getline(cin,nha_xuat_ban);
	cout<<"tac gia: ";
	getline(cin,tac_gia);
	cout<<"the loai: ";
	getline(cin,the_loai);
	cout<<"so luong: ";
	cin>>so_luong;
	while(cin.fail()||so_luong < 0){
		if (cin.fail()){
		   	cin.clear();
		   	cin.ignore(1000,'\n');
		   	cout<<"du lieu sai,nhap lai: ";
		   	cin>>so_luong;	
		}
		else if(so_luong < 0){
		   	cout<<"so luong ko the la so am,nhap lai: ";
		   	cin>>so_luong;
		}
	}
}

void Sach::Xuat()
{
	cout<<setw(10)<<ma_sach<<setw(18)<<tieu_de_sach<<setw(8)<<nam_xuat_ban;
	cout<<setw(12)<<nha_xuat_ban<<setw(12)<<tac_gia<<setw(14)<<the_loai<<setw(10)<<so_luong<<endl;
}

bool Sach::operator == (Sach b)
{
	return(tieu_de_sach == b.tieu_de_sach);
}
