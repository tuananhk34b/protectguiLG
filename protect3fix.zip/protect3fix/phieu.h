#include "sach.h"
#include <iomanip>
#include <string.h>
#include <stdlib.h>
class Phieu:public Sach
{	 
	protected:
		int ma_phieu_muon;
		int ma_so_nguoi_muon;
		string ten;
		string ngay_muon;
		string ngay_tra;
		string tinh_trang_sach_muon;
		string tinh_trang_sach_tra;
		bool trang_thai;
	public:
        Phieu();
        ~Phieu();
		int LayMaPhieuMuon();	 
		void SetMaSach(int); 
		void SetNgayTra(string);
	    void SetTinhTrangSachTra(string);
		void SetTrangThai(bool);
	    bool LayTrangThai();
		string LayNgayMuon();
		void NhapP();	 
		void XuatPMuon();
		void XuatPTra();
};
