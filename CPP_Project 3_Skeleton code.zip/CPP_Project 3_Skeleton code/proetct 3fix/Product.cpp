#include "Product.h"
#include <iostream>
#include <iomanip>

void Product::NhapSP(){
	cin.ignore();
	cout<<"ten san pham : ";
	getline(cin,ten_san_pham);
	cout<<"nam san xuat: ";
	cin>>nam_san_xuat;
	//thuc hien chuc nang nang cao :kt tra du lieu dau vao
	while(cin.fail()){
	    cin.clear();
		cin.ignore(1000,'\n');
		cout<<"khong phai so,nhap lai: ";
		cin>>nam_san_xuat;
	}
	cout<<"gia nhap: ";
	cin>>gia_nhap;
	while(cin.fail()){
	    cin.clear();
		cin.ignore(1000,'\n');
		cout<<"khong phai so,nhap lai: ";
		cin>>gia_nhap;
	}
}

void Product::XuatSP(){
	cout<<setw(25)<<ten_san_pham<<setw(20)<<gia_nhap;
}

string Product::LayTenSanPham()
{
	return ten_san_pham;
}
