#include "Order.h"
#include <iostream>
#include <iomanip>
using namespace std;
void Order::NhapHD(){
	cout<<"so luong: ";
	cin>>so_luong;
	while(cin.fail()){
	    cin.clear();
		cin.ignore(1000,'\n');
		cout<<"khong phai so,nhap lai: ";
		cin>>so_luong;
	}
	cout<<"gia ban: ";
	cin>>gia_ban;
	while(cin.fail()){
	    cin.clear();
		cin.ignore(1000,'\n');
		cout<<"khong phai so,nhap lai: ";
		cin>>gia_ban;
	}
}

void Order::XuatHD(){
	cout<<setw(10)<<so_luong<<setw(15)<<gia_ban;
}

int Order::ThanhTien(){
	int thanh_tien;
	thanh_tien  = so_luong*gia_ban;
	return thanh_tien;
}

float Order::VAT(){
	float VAT;
	VAT = (so_luong*gia_ban*10)/100;
	return VAT;
}

int Order::LoiNhuan(){
	int loi_nhuan;
	loi_nhuan = (gia_ban-gia_nhap)*so_luong;
}

int Order::LaySoLuong()
{
	return so_luong;
}
