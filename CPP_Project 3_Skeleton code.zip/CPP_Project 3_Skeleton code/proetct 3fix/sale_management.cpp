#include <iostream>
#include "Product.h"
#include "Order.h"
#include <iomanip>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*ung dung nay duoc viet tren dev c phien ban 5.11;*/
int main(int argc, char** argv) {
	 Order hd[10];
	 int n;
	 do
	 {
	 	cout<<"so hoa don: ";
	 	cin>>n;
	 	if (n < 1 || n > 10){
	 		cout<<"so hoa don chi tu 1 den 10,nhap lai: \n";
		}
	 } while(n < 1 || n > 10);
	 cout<<"nhap thong tin cac hoa don: \n\n";
	 for(int i = 0; i < n; i++)
	 {
	 	 cout<<"nhap thong tin hoa don: "<<i+1<<"\n";
	 	 hd[i].NhapSP();
	 	 hd[i].NhapHD();
	 }
	 for(int i = 0; i < n; i++)
	 {
	 	for(int j = i + 1; j < n; j++)
	 	{
	 		int loinhuan1 = hd[i].LoiNhuan();
	 		int loinhuan2 = hd[j].LoiNhuan();
	 		if (loinhuan1 < loinhuan2) {
	 		   Order oh = hd[i];
	 		   hd[i] = hd[j];
	 		   hd[j] = oh;
			}
		}
	 }
	 cout<<"danh sach hoa don sau khi sap xep tien lai giam dan: \n\n";
	 cout<<setw(4)<<"STT"<<setw(25)<<"ten san pham"<<setw(20)<<"gia nhap"<<setw(10)<<"so luong";
	 cout<<setw(15)<<"gia ban"<<setw(15)<<"thanh tien"<<setw(10)<<"VAT"<<setw(15)<<"tien lai"<<endl;
	 for(int i = 0; i < n; i++)
	 {
	 	 cout<<setw(4)<<i+1;
	 	 hd[i].XuatSP();
	 	 hd[i].XuatHD(); 
	 	 cout<<setw(15)<<hd[i].ThanhTien();
	 	 cout<<setw(10)<<hd[i].VAT();
	 	 cout<<setw(15)<<hd[i].LoiNhuan();
	 	 cout<<endl;
	 }
	 int tong_tien = 0;
	 for(int i = 0; i < n; i++)
	 {
	 	tong_tien=tong_tien + hd[i].ThanhTien();
	 }
	 cout<<"\ntong tien cac hoa don: "<< setw(47) << "" << setw(19)<<tong_tien;
	 float max=hd[0].VAT();
	 for(int i = 0; i < n; i++)
	 {
	 	 if(hd[i].VAT()>max)
	 	  max=hd[i].VAT();
	 }
	 cout<<"\n\ncac hoa don co tien thue cao nhat :\n\n";
	 cout<<setw(4)<<"STT"<<setw(25)<<"ten san pham"<<setw(20)<<"gia nhap"<<setw(10)<<"so luong";
	 cout<<setw(15)<<"gia ban"<<setw(15)<<"thanh tien"<<setw(10)<<"thue"<<setw(15)<<"tien lai"<<endl;
	 for(int i = 0; i < n; i++)
	 {
	 	 if (hd[i].VAT() == max){
	 	 	 cout<<setw(4)<<i+1;
		 	 hd[i].XuatSP();
		 	 hd[i].XuatHD(); 
		 	 cout<<setw(15)<<hd[i].ThanhTien();
		 	 cout<<setw(10)<<hd[i].VAT();
		 	 cout<<setw(15)<<hd[i].LoiNhuan();
		 	 cout<<endl;
		  } 	  
	 }
	 //thuc hien yeu cau nang cao ,xuat ra so luong ban nhieu nhat
	int max_so_luong = hd[0].LaySoLuong();
	for(int i = 0;i < n;i++)
	{
		if(hd[i].LaySoLuong() > max_so_luong)
		  max_so_luong=hd[i].LaySoLuong();
	}
	cout<<"\n\ncac hoa don co so luong ban nhieu nhat :\n\n";
	cout<<setw(4)<<"STT"<<setw(25)<<"ten san pham"<<setw(20)<<"gia nhap"<<setw(10)<<"so luong"<<setw(15)<<"gia ban"<<setw(15)<<"thanh tien"<<setw(10)<<"thue"<<setw(15)<<"tien lai"<<endl;
	for(int i = 0; i < n; i++)
	{
	 	if (hd[i].LaySoLuong() == max_so_luong){
	 	 	cout<<setw(4)<<i+1;
		 	hd[i].XuatSP();
		 	hd[i].XuatHD(); 
		 	cout<<setw(15)<<hd[i].ThanhTien();
		 	cout<<setw(10)<<hd[i].VAT();
		 	cout<<setw(15)<<hd[i].LoiNhuan();
		 	cout<<endl;
		} 	  
	}
	//thuc hien yeu cau nang cao ,them chuc nang tim kiem theo ten san pham
	string ten;
	int k = 0;
	cout<<"nhap ten san pham muon tim: ";
	cin.ignore();
	getline(cin,ten);
	cout<<"\n\ncac hoa don co co san pham can tim :\n\n";
	cout<<setw(4)<<"STT"<<setw(25)<<"ten san pham"<<setw(20)<<"gia nhap"<<setw(10)<<"so luong";
	cout<<setw(15)<<"gia ban"<<setw(15)<<"thanh tien"<<setw(10)<<"thue"<<setw(15)<<"tien lai"<<endl;
	for(int i = 0; i < n; i++)
	{
	 	if (hd[i].LayTenSanPham() == ten){
	 	 	cout<<setw(4)<<i+1;
		 	hd[i].XuatSP();
		 	hd[i].XuatHD(); 
		 	cout<<setw(15)<<hd[i].ThanhTien();
		 	cout<<setw(10)<<hd[i].VAT();
		 	cout<<setw(15)<<hd[i].LoiNhuan();
		 	cout<<endl;
		 	k = 1;
		} 	  
	}
	if(k == 0){
		cout<<"\nkhong tim thay san pham nay\n";
	}
	return 0;
}
