#pragma once
#include <string>
using namespace std;
class Product
{
	protected:
		string ten_san_pham;
		int nam_san_xuat;
		int gia_nhap;
	public:
	    void NhapSP();
	    void XuatSP();
	    string LayTenSanPham();
};
