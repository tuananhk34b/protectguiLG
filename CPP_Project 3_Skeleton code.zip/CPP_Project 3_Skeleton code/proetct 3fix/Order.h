#pragma once
#include "Product.h"
class Order : public Product
{
	protected:
		int so_luong;
		int gia_ban;
	public:
		void NhapHD();
		void XuatHD();
		int ThanhTien();
		float VAT();
		int LoiNhuan();
		int LaySoLuong();	
};
