IDE :protect nay duoc viet tren dev C phien ban 5.11
cac tinh nang nang cao da cai dat:  kiem tra du lieu nhap vao co dung khong
                                    xuat ra san pham so luong ban nhieu nhat
                                   them chuc nang tim kiem san pham